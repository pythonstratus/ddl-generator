package com.example.claudeconsole.claude;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/** Helpers for starting Claude Code, reading what it prints and stopping it. */
public final class ProcessSupport {

    private ProcessSupport() {
    }

    /**
     * Runs a short command to completion and captures its output. The command is started
     * directly, without a shell, so no argument is ever interpreted by one.
     */
    public static CommandResult run(List<String> command, Path workDir, String stdin, Duration timeout)
            throws IOException, InterruptedException {
        ProcessBuilder builder = new ProcessBuilder(command);
        if (workDir != null) {
            builder.directory(workDir.toFile());
        }
        Process process = builder.start();
        TailCollector out = TailCollector.start(process.getInputStream(), 64_000, null, "command-stdout");
        TailCollector err = TailCollector.start(process.getErrorStream(), 16_000, null, "command-stderr");
        writeAndClose(process, stdin);
        boolean finished = process.waitFor(timeout.toMillis(), TimeUnit.MILLISECONDS);
        if (!finished) {
            destroyTree(process, true);
            process.waitFor(5, TimeUnit.SECONDS);
        }
        return new CommandResult(finished ? process.exitValue() : -1, out.text(), err.text(), !finished);
    }

    /** Writes text to the process's standard input and closes it. */
    public static void writeAndClose(Process process, String text) {
        try (OutputStream stdin = process.getOutputStream()) {
            if (text != null && !text.isEmpty()) {
                stdin.write(text.getBytes(StandardCharsets.UTF_8));
            }
        } catch (IOException ignored) {
            // The process exited before reading its input; its exit code and stderr say why.
        }
    }

    /** Stops a process and every process it started. */
    public static void destroyTree(Process process, boolean force) {
        try {
            process.descendants().forEach(child -> {
                if (force) {
                    child.destroyForcibly();
                } else {
                    child.destroy();
                }
            });
        } catch (RuntimeException ignored) {
            // Listing child processes isn't supported everywhere; stop the main process anyway.
        }
        if (force) {
            process.destroyForcibly();
        } else {
            process.destroy();
        }
    }

    /** Thread factory for background threads that don't keep the JVM alive. */
    public static ThreadFactory daemonThreads(String prefix) {
        AtomicInteger counter = new AtomicInteger();
        return runnable -> {
            Thread thread = new Thread(runnable, prefix + counter.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        };
    }

    /** First non-blank line of the text, or "". */
    public static String firstLine(String text) {
        if (text == null) {
            return "";
        }
        String stripped = text.strip();
        int end = stripped.indexOf('\n');
        return (end < 0 ? stripped : stripped.substring(0, end)).strip();
    }

    /** The last {@code count} lines of the text. */
    public static String lastLines(String text, int count) {
        if (text == null || text.isBlank()) {
            return "";
        }
        String[] lines = text.strip().split("\\R");
        int from = Math.max(0, lines.length - count);
        return String.join("\n", Arrays.copyOfRange(lines, from, lines.length)).strip();
    }

    /** The text cut to {@code maxChars}, with an ellipsis when something was removed. */
    public static String truncate(String text, int maxChars) {
        if (text == null) {
            return "";
        }
        return text.length() <= maxChars ? text : text.substring(0, maxChars) + "\u2026";
    }

    /** Reads a stream on a background thread and keeps its last few thousand characters. */
    public static final class TailCollector {

        private final StringBuilder buffer = new StringBuilder();
        private final int maxChars;
        private final Thread thread;

        private TailCollector(InputStream in, int maxChars, Consumer<String> onLine, String threadName) {
            this.maxChars = maxChars;
            this.thread = new Thread(() -> pump(in, onLine), threadName);
            this.thread.setDaemon(true);
        }

        public static TailCollector start(InputStream in, int maxChars, Consumer<String> onLine, String threadName) {
            TailCollector collector = new TailCollector(in, maxChars, onLine, threadName);
            collector.thread.start();
            return collector;
        }

        private void pump(InputStream in, Consumer<String> onLine) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (onLine != null) {
                        try {
                            onLine.accept(line);
                        } catch (RuntimeException ignored) {
                            // A logging problem mustn't stop the stream from being drained.
                        }
                    }
                    synchronized (buffer) {
                        buffer.append(line).append('\n');
                        int excess = buffer.length() - maxChars;
                        if (excess > 0) {
                            buffer.delete(0, excess);
                        }
                    }
                }
            } catch (IOException ignored) {
                // The stream closes when the process ends or is stopped.
            }
        }

        /** Waits briefly for the stream to end, then returns what was collected. */
        public String text() {
            try {
                thread.join(2_000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            synchronized (buffer) {
                return buffer.toString().strip();
            }
        }
    }
}
