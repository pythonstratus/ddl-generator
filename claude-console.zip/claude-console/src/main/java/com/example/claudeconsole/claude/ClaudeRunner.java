package com.example.claudeconsole.claude;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.stereotype.Service;

import com.example.claudeconsole.config.ClaudeProperties;
import com.example.claudeconsole.status.ClaudeStatusService;
import com.example.claudeconsole.status.ClaudeStatusService.State;

/**
 * Runs one question through Claude Code in headless mode ({@code claude -p}) and streams what it
 * prints to the browser as {@link UiEvent}s.
 *
 * <p>The question is written to the CLI's standard input rather than its command line, so text
 * typed in the browser can never be read as a CLI flag. Each run ends with a {@code done} event.
 */
@Service
public class ClaudeRunner implements DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(ClaudeRunner.class);

    /** Retry reasons that point at the sign-in rather than at the service. */
    private static final Set<String> SIGN_IN_ERRORS = Set.of(
            "authentication_failed", "oauth_org_not_allowed", "cloud_credential_error", "account_on_hold");

    private final ClaudeProperties props;
    private final ClaudeCommandBuilder commands;
    private final ClaudeStatusService status;
    private final Semaphore slots;
    private final Map<String, Run> active = new ConcurrentHashMap<>();
    private final ExecutorService workers =
            Executors.newCachedThreadPool(ProcessSupport.daemonThreads("claude-run-"));
    private final ScheduledExecutorService timers =
            Executors.newSingleThreadScheduledExecutor(ProcessSupport.daemonThreads("claude-timer-"));

    public ClaudeRunner(ClaudeProperties props, ClaudeCommandBuilder commands, ClaudeStatusService status) {
        this.props = props;
        this.commands = commands;
        this.status = status;
        this.slots = new Semaphore(props.getMaxConcurrentRuns());
    }

    public String newRunId() {
        return UUID.randomUUID().toString();
    }

    /** Number of questions being answered right now. */
    public int activeRuns() {
        return active.size();
    }

    /**
     * Answers a question on a background thread, then calls {@code whenFinished}.
     *
     * @throws RejectedExecutionException if the app is shutting down
     */
    public void start(String runId, String prompt, String sessionId, EventSink sink, Runnable whenFinished) {
        workers.execute(() -> {
            try {
                run(runId, prompt, sessionId, sink);
            } finally {
                whenFinished.run();
            }
        });
    }

    /** Stops a run. Returns false if no run has that ID (it may already have finished). */
    public boolean cancel(String runId) {
        Run run = runId == null ? null : active.get(runId);
        if (run == null) {
            return false;
        }
        log.info("Run {}: stop requested", shortId(runId));
        stop(run, false);
        return true;
    }

    /** Answers one question, sending events to the sink as they happen. Never throws. */
    public void run(String runId, String prompt, String sessionId, EventSink sink) {
        Delivery out = new Delivery(sink);
        if (!slots.tryAcquire()) {
            out.send("error", message("busy", "Claude Code is already answering "
                    + props.getMaxConcurrentRuns() + " question(s). Try again when one finishes."));
            out.send("done", done(runId, null, false, false, null));
            return;
        }
        Run run = new Run();
        active.put(runId, run);
        StreamEventMapper mapper = new StreamEventMapper();
        boolean resuming = sessionId != null && !sessionId.isBlank();
        long startedAt = System.nanoTime();
        ScheduledFuture<?> timeout = null;
        Integer exitCode = null;
        boolean processStarted = false;
        String failure = null;
        try {
            out.send("start", Map.of("runId", runId));
            if (out.gone()) {
                return;
            }
            List<String> command = commands.chat(sessionId);
            Path workDir = props.workingDirectory();
            Files.createDirectories(workDir);

            Process process;
            try {
                process = new ProcessBuilder(command).directory(workDir.toFile()).start();
            } catch (IOException e) {
                failure = "Couldn't start Claude Code: " + String.valueOf(e.getMessage()).strip()
                        + ". Install Claude Code for this user account, or set claude.command to the full "
                        + "path of the claude executable.";
                out.send("error", message("cli_not_started", failure));
                return;
            }
            processStarted = true;
            log.info("Run {}: started {}", shortId(runId), String.join(" ", command));
            run.attach(process);
            timeout = schedule(() -> stop(run, true), props.getTimeoutSeconds(), TimeUnit.SECONDS);
            ProcessSupport.TailCollector stderr = ProcessSupport.TailCollector.start(
                    process.getErrorStream(), 8_000,
                    line -> log.warn("Run {} stderr: {}", shortId(runId), line),
                    "claude-stderr-" + shortId(runId));
            // Write on another thread so a large question can't deadlock against the output pipe.
            workers.execute(() -> ProcessSupport.writeAndClose(process, prompt));

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    for (UiEvent event : mapper.map(line)) {
                        out.send(event);
                    }
                    if (out.gone()) {
                        log.info("Run {}: the browser disconnected, stopping Claude Code", shortId(runId));
                        stop(run, false);
                        break;
                    }
                }
            } catch (IOException e) {
                if (!run.stopped()) {
                    failure = "Lost the connection to Claude Code's output (" + e.getMessage() + ").";
                }
            }

            if (!process.waitFor(15, TimeUnit.SECONDS)) {
                ProcessSupport.destroyTree(process, true);
                process.waitFor(5, TimeUnit.SECONDS);
            }
            exitCode = process.isAlive() ? null : process.exitValue();
            String errorOutput = stderr.text();

            if (run.timedOut()) {
                failure = "No answer after " + props.getTimeoutSeconds() + " seconds, so the run was stopped. "
                        + "Raise claude.timeout-seconds if answers need longer.";
            } else if (!run.stopped() && failure == null && !mapper.resultSeen()) {
                failure = describeFailure(exitCode, errorOutput);
            }
            if (failure != null) {
                out.send("error", message(run.timedOut() ? "timeout" : "cli_failed", failure));
            }
        } catch (IOException e) {
            failure = "Couldn't prepare Claude Code's working folder " + props.workingDirectory()
                    + " (" + e.getMessage() + ").";
            out.send("error", message("working_dir", failure));
        } catch (IllegalArgumentException | IllegalStateException e) {
            failure = e.getMessage();
            out.send("error", message("config", failure));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            stop(run, false);
            failure = "The app stopped this question while shutting down.";
            out.send("error", message("interrupted", failure));
        } catch (RuntimeException e) {
            log.error("Run {} failed", shortId(runId), e);
            failure = "Unexpected error: " + e;
            out.send("error", message("internal", failure));
        } finally {
            if (timeout != null) {
                timeout.cancel(false);
            }
            run.destroy(true);
            active.remove(runId);
            slots.release();
            long elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedAt);
            recordOutcome(mapper, run, failure, elapsedMs);

            String reset = null;
            if (run.timedOut()) {
                reset = "timeout";
            } else if (run.stopped()) {
                reset = "stopped";
            } else if (resuming && processStarted && !mapper.resultSeen()) {
                reset = "resume_failed";
            }
            out.send("done", done(runId, exitCode, run.stopped() && !run.timedOut(), run.timedOut(), reset));
            log.info("Run {}: finished in {} ms, exit code {}{}", shortId(runId), elapsedMs, exitCode,
                    reset == null ? "" : " (" + reset + ")");
        }
    }

    @Override
    public void destroy() {
        for (Run run : active.values()) {
            run.markStopped(false);
            run.destroy(true);
        }
        workers.shutdownNow();
        timers.shutdownNow();
    }

    /** Explains a run that ended without a result. */
    static String describeFailure(Integer exitCode, String stderr) {
        StringBuilder text = new StringBuilder("Claude Code ");
        if (exitCode == null) {
            text.append("didn't exit");
        } else if (exitCode == 0) {
            text.append("finished without an answer");
        } else {
            text.append("exited with code ").append(exitCode);
        }
        String detail = ProcessSupport.truncate(ProcessSupport.lastLines(stderr, 6), 1_500);
        if (detail.isEmpty()) {
            text.append(". Run claude -p \"hello\" in a terminal, as the same user, to see why.");
        } else {
            text.append(": ").append(detail);
            if (detail.toLowerCase(Locale.ROOT).contains("unknown option")) {
                text.append("\nThis Claude Code version doesn't support one of the flags. Update Claude Code, "
                        + "or remove the flag from claude.extra-args (for --include-partial-messages, set "
                        + "claude.partial-messages=false).");
            }
        }
        return text.toString();
    }

    private void recordOutcome(StreamEventMapper mapper, Run run, String failure, long elapsedMs) {
        String model = mapper.model();
        boolean failed;
        if (failure != null) {
            status.recordRun(State.ERROR, "Failed", failure, model);
            failed = true;
        } else if (run.stopped()) {
            status.recordRun(State.WARN, "Stopped", "The last question was stopped before it finished.", model);
            failed = false;
        } else if (mapper.resultSeen() && mapper.resultIsError()) {
            status.recordRun(State.ERROR, "Failed", mapper.resultText(), model);
            failed = true;
        } else if (mapper.resultSeen()) {
            status.recordRun(State.OK, "Answered", "Answered in "
                    + String.format(Locale.ROOT, "%.1f", elapsedMs / 1000.0) + " seconds.", model);
            failed = false;
        } else {
            return;
        }
        if (failed && SIGN_IN_ERRORS.contains(mapper.lastRetryError())) {
            status.markSignInProblem("Claude Code's sign-in was rejected (" + mapper.lastRetryError()
                    + "). Sign in again in a terminal, then select Check again.");
        }
    }

    private void stop(Run run, boolean byTimeout) {
        if (!run.markStopped(byTimeout)) {
            return;
        }
        run.destroy(false);
        // If Claude Code ignores the polite request, end it a few seconds later.
        schedule(() -> run.destroy(true), 5, TimeUnit.SECONDS);
    }

    private ScheduledFuture<?> schedule(Runnable task, long delay, TimeUnit unit) {
        try {
            return timers.schedule(task, delay, unit);
        } catch (RejectedExecutionException e) {
            return null; // shutting down; destroy() stops every process
        }
    }

    private static Map<String, Object> message(String code, String text) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("code", code);
        data.put("message", text == null ? "" : text);
        return data;
    }

    private static Map<String, Object> done(String runId, Integer exitCode, boolean stopped, boolean timedOut,
            String resetReason) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("runId", runId);
        data.put("exitCode", exitCode);
        data.put("stopped", stopped);
        data.put("timedOut", timedOut);
        data.put("resetConversation", resetReason != null);
        data.put("resetReason", resetReason);
        return data;
    }

    private static String shortId(String runId) {
        return runId == null || runId.length() < 8 ? String.valueOf(runId) : runId.substring(0, 8);
    }

    /** State of one run, shared between the reading thread, the timer and stop requests. */
    private static final class Run {

        private Process process;
        private boolean stopped;
        private boolean timedOut;

        synchronized void attach(Process started) {
            process = started;
            if (stopped) {
                ProcessSupport.destroyTree(started, false);
            }
        }

        /** Marks the run as stopped; returns false if it already was. */
        synchronized boolean markStopped(boolean byTimeout) {
            if (stopped) {
                return false;
            }
            stopped = true;
            timedOut = byTimeout;
            return true;
        }

        synchronized boolean stopped() {
            return stopped;
        }

        synchronized boolean timedOut() {
            return timedOut;
        }

        void destroy(boolean force) {
            Process current;
            synchronized (this) {
                current = process;
            }
            if (current != null && current.isAlive()) {
                ProcessSupport.destroyTree(current, force);
            }
        }
    }

    /** Sends events to the browser and remembers when it has gone away. */
    private static final class Delivery {

        private final EventSink sink;
        private volatile boolean gone;

        Delivery(EventSink sink) {
            this.sink = sink;
        }

        void send(String name, Map<String, Object> data) {
            send(new UiEvent(name, data));
        }

        void send(UiEvent event) {
            if (gone) {
                return;
            }
            try {
                sink.send(event);
            } catch (IOException | RuntimeException e) {
                gone = true;
            }
        }

        boolean gone() {
            return gone;
        }
    }
}
