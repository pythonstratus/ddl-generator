package com.example.claudeconsole.web;

import java.util.Map;

/**
 * Response headers added to every page and API response.
 *
 * <p>The page loads nothing from other sites and has no inline scripts or styles, so the
 * Content-Security-Policy can allow only this app's own files. If an answer ever contained
 * something that slipped past the Markdown renderer, the browser still wouldn't run it.
 */
public final class SecurityHeaders {

    public static final String CONTENT_SECURITY_POLICY = "default-src 'self'; script-src 'self'; "
            + "style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; "
            + "base-uri 'none'; form-action 'self'; frame-ancestors 'none'";

    public static final Map<String, String> ALL = Map.of(
            "Content-Security-Policy", CONTENT_SECURITY_POLICY,
            "X-Content-Type-Options", "nosniff",
            "X-Frame-Options", "DENY",
            "Referrer-Policy", "no-referrer");

    private SecurityHeaders() {
    }
}
