package com.example.claudeconsole.claude;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.example.claudeconsole.config.ClaudeProperties;

/**
 * Builds the Claude Code command lines this app runs. Nothing typed in the browser is ever put
 * on a command line: questions go to standard input, and the only other browser value, the
 * conversation ID, must be a UUID.
 */
@Component
public class ClaudeCommandBuilder {

    private static final Pattern SESSION_ID = Pattern.compile(
            "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    private final ClaudeProperties props;

    public ClaudeCommandBuilder(ClaudeProperties props) {
        this.props = props;
    }

    /** Command for one question, continuing the given conversation when {@code sessionId} is set. */
    public List<String> chat(String sessionId) {
        List<String> command = base();
        command.add("-p");
        command.add("--output-format");
        command.add("stream-json");
        command.add("--verbose");
        if (props.isPartialMessages()) {
            command.add("--include-partial-messages");
        }
        addModel(command);
        if (sessionId != null && !sessionId.isBlank()) {
            if (!isValidSessionId(sessionId)) {
                throw new IllegalArgumentException("This conversation can't be continued. Start a new conversation.");
            }
            command.add("--resume");
            command.add(sessionId);
        }
        command.addAll(props.getExtraArgs());
        addDisallowedTools(command);
        return command;
    }

    /** Command for the one-word test prompt used when {@code claude.status.check=prompt}. */
    public List<String> ping() {
        List<String> command = base();
        command.add("-p");
        command.add("--output-format");
        command.add("json");
        addModel(command);
        command.addAll(props.getExtraArgs());
        addDisallowedTools(command);
        return command;
    }

    /** {@code claude --version} */
    public List<String> version() {
        List<String> command = base();
        command.add("--version");
        return command;
    }

    /** {@code claude auth status} */
    public List<String> authStatus() {
        List<String> command = base();
        command.add("auth");
        command.add("status");
        return command;
    }

    /** True if the value is a UUID, the only form Claude Code uses for session IDs. */
    public static boolean isValidSessionId(String value) {
        return value != null && SESSION_ID.matcher(value).matches();
    }

    private List<String> base() {
        List<String> command = props.getCommand();
        if (command == null || command.isEmpty()) {
            throw new IllegalStateException("claude.command is empty. Set it to the claude executable.");
        }
        return new ArrayList<>(command);
    }

    private void addModel(List<String> command) {
        String model = props.getModel();
        if (model.isEmpty()) {
            return;
        }
        if (model.startsWith("-")) {
            throw new IllegalStateException("claude.model can't start with '-'.");
        }
        command.add("--model");
        command.add(model);
    }

    /** Added last, because the flag reads every following value as a tool name. */
    private void addDisallowedTools(List<String> command) {
        List<String> tools = props.getDisallowedTools();
        if (tools.isEmpty()) {
            return;
        }
        command.add("--disallowedTools");
        command.addAll(tools);
    }
}
