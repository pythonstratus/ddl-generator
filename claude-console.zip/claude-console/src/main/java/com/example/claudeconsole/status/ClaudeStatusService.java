package com.example.claudeconsole.status;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.claudeconsole.claude.ClaudeCommandBuilder;
import com.example.claudeconsole.claude.CommandResult;
import com.example.claudeconsole.claude.ProcessSupport;
import com.example.claudeconsole.config.ClaudeProperties;
import com.example.claudeconsole.json.Json;

/**
 * Keeps the connection status shown at the top of the page: whether Claude Code starts, whether
 * it's signed in, and how the last question went.
 */
@Service
public class ClaudeStatusService {

    /** Light colors on the page: green, amber, red and grey. */
    public enum State { OK, WARN, ERROR, UNKNOWN }

    /** One status line: its state, a short summary, a longer explanation and when it was checked. */
    public record Check(State state, String summary, String detail, String checkedAt) {

        Map<String, Object> toMap() {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("state", state.name());
            map.put("summary", summary);
            map.put("detail", detail);
            map.put("checkedAt", checkedAt);
            return map;
        }
    }

    private static final Logger log = LoggerFactory.getLogger(ClaudeStatusService.class);
    private static final Pattern VERSION = Pattern.compile("\\d+\\.\\d+\\.\\d+(?:[-+][0-9A-Za-z.-]+)?");
    private static final Pattern SECRET_NAME =
            Pattern.compile("(?i).*(token|secret|password|credential|cookie|key).*");
    private static final String TEST_PROMPT = "Reply with the single word OK.";

    private final ClaudeProperties props;
    private final ClaudeCommandBuilder commands;
    private final AtomicBoolean checking = new AtomicBoolean();

    private volatile Check cli = new Check(State.UNKNOWN, "Checking",
            "The first check runs a moment after startup.", null);
    private volatile Check signIn = new Check(State.UNKNOWN, "Checking",
            "The first check runs a moment after startup.", null);
    private volatile Check lastRun = new Check(State.UNKNOWN, "None yet",
            "No questions have been asked since the app started.", null);
    private volatile String lastModel = "";
    private volatile Instant lastTestPrompt = Instant.EPOCH;

    public ClaudeStatusService(ClaudeProperties props, ClaudeCommandBuilder commands) {
        this.props = props;
        this.commands = commands;
    }

    @Scheduled(initialDelayString = "${claude.status.initial-delay-ms:1500}",
            fixedDelayString = "${claude.status.interval-ms:60000}")
    public void scheduledCheck() {
        refresh(false);
    }

    /** Runs the checks now. Returns straight away if a check is already running. */
    public void refresh(boolean requestedByUser) {
        if (!checking.compareAndSet(false, true)) {
            return;
        }
        try {
            cli = checkCli();
            if (cli.state() == State.ERROR) {
                signIn = new Check(State.UNKNOWN, "Not checked",
                        "Sign-in can't be checked until Claude Code starts.", now());
                return;
            }
            String mode = checkMode();
            if ("prompt".equals(mode) && !requestedByUser && signIn.checkedAt() != null
                    && Duration.between(lastTestPrompt, Instant.now()).toMinutes()
                            < props.getStatus().getPromptIntervalMinutes()) {
                return; // test prompts use tokens, so they run less often than the other checks
            }
            signIn = checkSignIn(mode);
        } catch (RuntimeException e) {
            log.warn("Status check failed", e);
        } finally {
            checking.set(false);
        }
    }

    /** Records how a question ended, for the "Last question" light. */
    public void recordRun(State state, String summary, String detail, String model) {
        lastRun = new Check(state, summary, detail, now());
        if (model != null && !model.isBlank()) {
            lastModel = model;
        }
        // An answered question proves the sign-in works. A WARN result is left alone because it
        // already explains that the check and the questions disagree.
        if (state == State.OK && (signIn.state() == State.ERROR || signIn.state() == State.UNKNOWN)) {
            signIn = new Check(State.OK, "Working",
                    "Your last question was answered, so Claude Code's sign-in works.", now());
        }
    }

    /** Turns the sign-in light red after Claude Code reported an authentication failure. */
    public void markSignInProblem(String detail) {
        signIn = new Check(State.ERROR, "Rejected", detail, now());
    }

    /** Everything the page shows about the connection. */
    public Map<String, Object> snapshot() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("cli", cli.toMap());
        data.put("signIn", signIn.toMap());
        data.put("lastRun", lastRun.toMap());
        data.put("model", lastModel);
        data.put("configuredModel", props.getModel());
        data.put("checking", checking.get());
        data.put("checkMode", checkMode());
        data.put("command", String.join(" ", props.getCommand()));
        data.put("workingDir", props.workingDirectory().toString());
        data.put("serverTime", now());
        return data;
    }

    // ------------------------------------------------------------------ checks

    private Check checkCli() {
        String program = String.join(" ", props.getCommand());
        CommandResult result;
        try {
            result = runCommand(commands.version(), null);
        } catch (IOException e) {
            return new Check(State.ERROR, "Not found", "Couldn't start Claude Code: "
                    + String.valueOf(e.getMessage()).strip() + ". Install Claude Code for this user account, "
                    + "or set claude.command to the full path of the claude executable.", now());
        } catch (IllegalStateException e) {
            return new Check(State.ERROR, "Not set up", e.getMessage(), now());
        }
        if (result == null) {
            return interrupted();
        }
        if (result.timedOut()) {
            return new Check(State.ERROR, "Not responding", "\"" + program + " --version\" didn't finish within "
                    + props.getStatus().getTimeoutSeconds() + " seconds.", now());
        }
        if (result.exitCode() != 0) {
            return new Check(State.ERROR, "Not working", "\"" + program + " --version\" exited with code "
                    + result.exitCode() + ". " + shortOutput(result), now());
        }
        String firstLine = ProcessSupport.firstLine(result.stdout());
        Matcher version = VERSION.matcher(firstLine);
        String summary = version.find() ? "v" + version.group() : "Installed";
        return new Check(State.OK, summary, firstLine + " (started with \"" + program + "\")", now());
    }

    private Check checkSignIn(String mode) {
        switch (mode) {
            case "none":
                return new Check(State.UNKNOWN, "Not checked", "Sign-in checks are off "
                        + "(claude.status.check=none). This light turns green after a question is answered.", now());
            case "prompt":
                return checkWithTestPrompt();
            case "auth-status":
                return checkAuthStatus();
            default:
                return new Check(State.WARN, "Unknown check", "claude.status.check is \"" + mode
                        + "\". Use auth-status, prompt or none.", now());
        }
    }

    private Check checkAuthStatus() {
        CommandResult result;
        try {
            result = runCommand(commands.authStatus(), null);
        } catch (IOException | IllegalStateException e) {
            return new Check(State.WARN, "Not checked", "Couldn't run claude auth status (" + e.getMessage() + ").", now());
        }
        if (result == null) {
            return interrupted();
        }
        if (result.timedOut()) {
            return new Check(State.WARN, "No reply", "claude auth status didn't finish within "
                    + props.getStatus().getTimeoutSeconds() + " seconds.", now());
        }
        String summary = summarizeAuth(result.stdout());
        if (result.exitCode() == 0) {
            return new Check(State.OK, "Signed in",
                    summary.isEmpty() ? "claude auth status reports that you're signed in." : summary, now());
        }
        if (result.exitCode() == 1) {
            if (lastRun.state() == State.OK) {
                return new Check(State.WARN, "Can't confirm", "claude auth status reports no Claude sign-in, "
                        + "but questions are being answered. Your organization probably connects Claude Code "
                        + "through a cloud provider or gateway. Set claude.status.check=prompt (or none) to "
                        + "check it that way instead.", now());
            }
            return new Check(State.ERROR, "Not signed in", "claude auth status reports no sign-in. Run claude "
                    + "in a terminal as this user and sign in, then select Check again. If your organization "
                    + "connects Claude Code through Amazon Bedrock, Google Vertex AI, Microsoft Foundry or a "
                    + "gateway, set claude.status.check=prompt instead."
                    + (summary.isEmpty() ? "" : " Details: " + summary), now());
        }
        return new Check(State.WARN, "Unknown", "claude auth status exited with code " + result.exitCode()
                + ". " + shortOutput(result) + " Older Claude Code versions don't have this command: update "
                + "Claude Code, or set claude.status.check=prompt.", now());
    }

    private Check checkWithTestPrompt() {
        lastTestPrompt = Instant.now();
        long startedAt = System.nanoTime();
        CommandResult result;
        try {
            result = runCommand(commands.ping(), TEST_PROMPT);
        } catch (IOException e) {
            return new Check(State.ERROR, "Test failed", "Couldn't send the test prompt (" + e.getMessage() + ").", now());
        } catch (IllegalStateException e) {
            return new Check(State.ERROR, "Test failed", e.getMessage(), now());
        }
        if (result == null) {
            return interrupted();
        }
        long elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedAt);
        if (result.timedOut()) {
            return new Check(State.ERROR, "No reply", "The test prompt got no reply within "
                    + props.getStatus().getTimeoutSeconds() + " seconds.", now());
        }
        Map<String, Object> json = Json.parseObjectOrNull(lastJsonLine(result.stdout()));
        if (json != null && result.exitCode() == 0 && !Json.bool(json, "is_error")) {
            Map<String, Object> usage = Json.object(json, "modelUsage");
            String model = usage.isEmpty() ? "" : usage.keySet().iterator().next();
            if (!model.isEmpty()) {
                lastModel = model;
            }
            return new Check(State.OK, "Connected", "A test prompt was answered in "
                    + String.format(Locale.ROOT, "%.1f", elapsedMs / 1000.0) + " seconds"
                    + (model.isEmpty() ? "." : " by " + model + "."), now());
        }
        String reason = json == null ? "" : Json.string(json, "result");
        if (reason.isBlank()) {
            reason = "exit code " + result.exitCode() + ". " + shortOutput(result);
        }
        return new Check(State.ERROR, "Test failed", "The test prompt failed: " + reason, now());
    }

    // ------------------------------------------------------------------ helpers

    /** Readable, secret-free summary of {@code claude auth status} output. */
    static String summarizeAuth(String stdout) {
        Map<String, Object> json = Json.parseObjectOrNull(stdout == null ? "" : stdout.strip());
        if (json == null) {
            return ProcessSupport.truncate(ProcessSupport.firstLine(stdout), 200);
        }
        List<String> parts = new ArrayList<>();
        for (Map.Entry<String, Object> entry : json.entrySet()) {
            Object value = entry.getValue();
            boolean simple = value instanceof String || value instanceof Number || value instanceof Boolean;
            if (simple && !SECRET_NAME.matcher(entry.getKey()).matches()) {
                parts.add(entry.getKey() + ": " + value);
            }
        }
        return ProcessSupport.truncate(String.join(", ", parts), 400);
    }

    private static String lastJsonLine(String stdout) {
        if (stdout == null) {
            return "";
        }
        String[] lines = stdout.strip().split("\\R");
        for (int i = lines.length - 1; i >= 0; i--) {
            if (lines[i].strip().startsWith("{")) {
                return lines[i].strip();
            }
        }
        return stdout.strip();
    }

    private static String shortOutput(CommandResult result) {
        String text = result.stderr().isBlank() ? result.stdout() : result.stderr();
        return ProcessSupport.truncate(ProcessSupport.lastLines(text, 4), 400);
    }

    private CommandResult runCommand(List<String> command, String stdin) throws IOException {
        Path dir = props.workingDirectory();
        Files.createDirectories(dir);
        try {
            return ProcessSupport.run(command, dir, stdin, Duration.ofSeconds(props.getStatus().getTimeoutSeconds()));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
    }

    private String checkMode() {
        String mode = props.getStatus().getCheck();
        return mode == null || mode.isBlank() ? "auth-status" : mode.strip().toLowerCase(Locale.ROOT);
    }

    private static Check interrupted() {
        return new Check(State.UNKNOWN, "Not checked", "The check was interrupted.", now());
    }

    private static String now() {
        return Instant.now().toString();
    }
}
