package com.example.claudeconsole.config;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Settings under {@code claude.*} in application.yml. Any of them can be overridden on the
 * command line, for example {@code java -jar app.jar --claude.timeout-seconds=900}.
 */
@ConfigurationProperties(prefix = "claude")
public class ClaudeProperties {

    /** Program (and any leading arguments) that starts Claude Code. */
    private List<String> command = new ArrayList<>(List.of("claude"));

    /** Folder Claude Code runs in. Blank means ~/.claude-console/workspace. Keep it empty. */
    private String workingDir = "";

    /** Model alias or full model name. Blank uses Claude Code's default. */
    private String model = "";

    /**
     * Tools removed from every run. "*" removes all of them; the names after it cover
     * Claude Code versions that don't understand "*".
     */
    private List<String> disallowedTools = new ArrayList<>(List.of(
            "*", "Bash", "PowerShell", "Edit", "MultiEdit", "Write", "NotebookEdit",
            "WebFetch", "WebSearch", "mcp__*"));

    /**
     * Stream the answer as it's written (--include-partial-messages). Turn off for Claude Code
     * versions without that flag; answers then appear all at once.
     */
    private boolean partialMessages = true;

    /** Extra flags added to every question and to the test prompt. */
    private List<String> extraArgs = new ArrayList<>(List.of("--strict-mcp-config"));

    /** Seconds before an unfinished answer is stopped (minimum 10). */
    private int timeoutSeconds = 600;

    /** How many questions may run at the same time (minimum 1). */
    private int maxConcurrentRuns = 2;

    /** Longest question accepted, in characters. */
    private int maxPromptChars = 100_000;

    private final Status status = new Status();

    /** The working folder as an absolute path, with a leading ~ expanded. */
    public Path workingDirectory() {
        String home = System.getProperty("user.home");
        String dir = workingDir == null ? "" : workingDir.strip();
        if (dir.isEmpty()) {
            return Path.of(home, ".claude-console", "workspace");
        }
        if (dir.equals("~") || dir.startsWith("~/") || dir.startsWith("~\\")) {
            dir = home + dir.substring(1);
        }
        return Path.of(dir).toAbsolutePath().normalize();
    }

    public List<String> getCommand() {
        return command;
    }

    public void setCommand(List<String> command) {
        this.command = copy(command);
    }

    public String getWorkingDir() {
        return workingDir;
    }

    public void setWorkingDir(String workingDir) {
        this.workingDir = workingDir;
    }

    public String getModel() {
        return model == null ? "" : model.strip();
    }

    public void setModel(String model) {
        this.model = model;
    }

    public List<String> getDisallowedTools() {
        return disallowedTools;
    }

    public void setDisallowedTools(List<String> disallowedTools) {
        this.disallowedTools = copy(disallowedTools);
    }

    public boolean isPartialMessages() {
        return partialMessages;
    }

    public void setPartialMessages(boolean partialMessages) {
        this.partialMessages = partialMessages;
    }

    public List<String> getExtraArgs() {
        return extraArgs;
    }

    public void setExtraArgs(List<String> extraArgs) {
        this.extraArgs = copy(extraArgs);
    }

    public int getTimeoutSeconds() {
        return Math.max(10, timeoutSeconds);
    }

    public void setTimeoutSeconds(int timeoutSeconds) {
        this.timeoutSeconds = timeoutSeconds;
    }

    public int getMaxConcurrentRuns() {
        return Math.max(1, maxConcurrentRuns);
    }

    public void setMaxConcurrentRuns(int maxConcurrentRuns) {
        this.maxConcurrentRuns = maxConcurrentRuns;
    }

    public int getMaxPromptChars() {
        return Math.max(1, maxPromptChars);
    }

    public void setMaxPromptChars(int maxPromptChars) {
        this.maxPromptChars = maxPromptChars;
    }

    public Status getStatus() {
        return status;
    }

    private static List<String> copy(List<String> values) {
        List<String> result = new ArrayList<>();
        if (values != null) {
            for (String value : values) {
                if (value != null && !value.isBlank()) {
                    result.add(value.strip());
                }
            }
        }
        return result;
    }

    /** Settings under {@code claude.status.*}. */
    public static class Status {

        /** How the sign-in light is checked: auth-status, prompt or none. */
        private String check = "auth-status";

        /** Milliseconds between automatic checks (read by the scheduler). */
        private long intervalMs = 60_000;

        /** In prompt mode, minutes between automatic test prompts. Each one uses a few tokens. */
        private int promptIntervalMinutes = 30;

        /** Seconds before a check gives up (minimum 5). */
        private int timeoutSeconds = 60;

        public String getCheck() {
            return check;
        }

        public void setCheck(String check) {
            this.check = check;
        }

        public long getIntervalMs() {
            return intervalMs;
        }

        public void setIntervalMs(long intervalMs) {
            this.intervalMs = intervalMs;
        }

        public int getPromptIntervalMinutes() {
            return Math.max(1, promptIntervalMinutes);
        }

        public void setPromptIntervalMinutes(int promptIntervalMinutes) {
            this.promptIntervalMinutes = promptIntervalMinutes;
        }

        public int getTimeoutSeconds() {
            return Math.max(5, timeoutSeconds);
        }

        public void setTimeoutSeconds(int timeoutSeconds) {
            this.timeoutSeconds = timeoutSeconds;
        }
    }
}
