package com.example.claudeconsole.web;

import java.util.Locale;
import java.util.Map;

import com.example.claudeconsole.claude.ClaudeCommandBuilder;
import com.example.claudeconsole.json.Json;

/** A question from the browser: the text and, for follow-ups, the conversation to continue. */
public record ChatRequest(String prompt, String sessionId) {

    /**
     * Reads and checks the request body.
     *
     * @throws IllegalArgumentException with a message for the person asking, if the request can't be used
     */
    public static ChatRequest fromJson(String body, int maxPromptChars) {
        Map<String, Object> json = Json.parseObjectOrNull(body);
        if (json == null) {
            throw new IllegalArgumentException("The request wasn't valid JSON.");
        }
        String prompt = Json.string(json, "prompt").strip();
        String sessionId = Json.string(json, "sessionId").strip();
        if (prompt.isEmpty()) {
            throw new IllegalArgumentException("Type a question first.");
        }
        if (prompt.length() > maxPromptChars) {
            throw new IllegalArgumentException(String.format(Locale.ROOT,
                    "The question is %,d characters long. The limit is %,d (claude.max-prompt-chars).",
                    prompt.length(), maxPromptChars));
        }
        if (!sessionId.isEmpty() && !ClaudeCommandBuilder.isValidSessionId(sessionId)) {
            throw new IllegalArgumentException("This conversation can't be continued. Start a new conversation.");
        }
        return new ChatRequest(prompt, sessionId);
    }
}
