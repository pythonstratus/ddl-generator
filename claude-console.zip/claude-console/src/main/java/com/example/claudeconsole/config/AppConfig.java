package com.example.claudeconsole.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Turns on the settings classes and the status scheduler, and reports problems at startup. */
@Configuration(proxyBeanMethods = false)
@EnableScheduling
@EnableConfigurationProperties({ClaudeProperties.class, ConsoleProperties.class})
public class AppConfig {

    private static final Logger log = LoggerFactory.getLogger(AppConfig.class);

    @Bean
    ApplicationRunner startupReport(ClaudeProperties claude, ResourceLoader resources, Environment env) {
        return args -> {
            checkWorkingFolder(claude.workingDirectory());
            if (!resources.getResource("classpath:/static/index.html").exists()) {
                log.warn("The web page isn't in this build: src/main/resources/static/index.html is missing. "
                        + "Restore it and rebuild with 'mvn clean package'.");
            }
            String address = env.getProperty("server.address", "localhost");
            if ("0.0.0.0".equals(address) || "::".equals(address)) {
                log.warn("server.address is {}, so other computers can reach this app and use your "
                        + "Claude Code sign-in.", address);
                address = "localhost";
            }
            if (address.contains(":")) {
                address = "[" + address + "]";
            }
            String port = env.getProperty("local.server.port", env.getProperty("server.port", "8080"));
            log.info("Claude console is ready at http://{}:{}", address, port);
        };
    }

    private static void checkWorkingFolder(Path dir) {
        try {
            Files.createDirectories(dir);
            try (Stream<Path> entries = Files.list(dir)) {
                List<String> names = entries.limit(5).map(p -> String.valueOf(p.getFileName())).toList();
                if (!names.isEmpty()) {
                    log.warn("Claude Code's working folder {} isn't empty ({}). Claude Code loads settings, "
                            + "hooks and MCP servers from its working folder, so keep this folder empty.",
                            dir, String.join(", ", names));
                }
            }
        } catch (IOException e) {
            log.warn("Couldn't prepare the working folder {}: {}", dir, e.getMessage());
        }
    }
}
