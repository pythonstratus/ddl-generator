package com.example.claudeconsole.claude;

import java.util.Map;

/**
 * One event for the browser: a name such as "delta" or "result" and a payload of plain values
 * (strings, numbers, booleans, lists and maps) that can be written as JSON.
 */
public record UiEvent(String name, Map<String, Object> data) {
}
