package com.example.claudeconsole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Starts the local web page that sends questions to Claude Code. */
@SpringBootApplication
public class ClaudeConsoleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClaudeConsoleApplication.class, args);
    }
}
