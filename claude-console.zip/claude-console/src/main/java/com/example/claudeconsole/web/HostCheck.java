package com.example.claudeconsole.web;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Locale;

/** Reads host names from Host and Origin headers and compares them with the allowed names. */
public final class HostCheck {

    private HostCheck() {
    }

    /** Host name from a Host header, without the port or IPv6 brackets, in lower case. */
    public static String hostFromHeader(String header) {
        if (header == null) {
            return "";
        }
        String value = header.strip().toLowerCase(Locale.ROOT);
        if (value.startsWith("[")) {
            int end = value.indexOf(']');
            return end > 0 ? value.substring(1, end) : "";
        }
        int colon = value.indexOf(':');
        if (colon >= 0 && value.indexOf(':', colon + 1) < 0) {
            return value.substring(0, colon); // host:port
        }
        return value; // bare host name, or an IPv6 address without brackets
    }

    /** Host name from an Origin header such as {@code http://localhost:5173}, or "" if there is none. */
    public static String hostFromOrigin(String origin) {
        if (origin == null) {
            return "";
        }
        try {
            String host = new URI(origin.strip()).getHost();
            if (host == null) {
                return ""; // includes the literal Origin "null" sent by sandboxed pages
            }
            host = host.toLowerCase(Locale.ROOT);
            if (host.startsWith("[") && host.endsWith("]")) {
                host = host.substring(1, host.length() - 1);
            }
            return host;
        } catch (URISyntaxException e) {
            return "";
        }
    }

    /** True if the host name is in the allowed list (case-insensitive, IPv6 brackets optional). */
    public static boolean isAllowed(String host, Collection<String> allowed) {
        if (host == null || host.isEmpty() || allowed == null) {
            return false;
        }
        for (String entry : allowed) {
            if (entry == null) {
                continue;
            }
            String name = entry.strip().toLowerCase(Locale.ROOT);
            if (name.startsWith("[") && name.endsWith("]")) {
                name = name.substring(1, name.length() - 1);
            }
            if (!name.isEmpty() && name.equals(host)) {
                return true;
            }
        }
        return false;
    }

    /** A header value that is safe to write to the log. */
    public static String forLog(String value) {
        if (value == null) {
            return "(none)";
        }
        String cleaned = value.replaceAll("\\p{Cntrl}", "?");
        return cleaned.length() > 100 ? cleaned.substring(0, 100) + "\u2026" : cleaned;
    }
}
