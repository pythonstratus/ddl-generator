package com.example.claudeconsole.claude;

import java.io.IOException;

/** Where a run sends its events, normally the browser's server-sent-event stream. */
@FunctionalInterface
public interface EventSink {

    /**
     * Delivers one event.
     *
     * @throws IOException when the browser has gone away
     */
    void send(UiEvent event) throws IOException;
}
