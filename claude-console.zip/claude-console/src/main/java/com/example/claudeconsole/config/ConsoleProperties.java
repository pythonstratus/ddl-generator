package com.example.claudeconsole.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** Settings under {@code console.*} in application.yml. */
@ConfigurationProperties(prefix = "console")
public class ConsoleProperties {

    /**
     * Host names the browser may use to reach the app. Requests addressed to any other name
     * are refused, which blocks DNS-rebinding attacks and cross-site requests from web pages.
     */
    private List<String> allowedHosts = new ArrayList<>(List.of("localhost", "127.0.0.1", "::1"));

    public List<String> getAllowedHosts() {
        return allowedHosts;
    }

    public void setAllowedHosts(List<String> allowedHosts) {
        this.allowedHosts = allowedHosts == null ? new ArrayList<>() : new ArrayList<>(allowedHosts);
    }
}
