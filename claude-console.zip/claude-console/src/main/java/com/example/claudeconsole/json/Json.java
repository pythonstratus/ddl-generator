package com.example.claudeconsole.json;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Small JSON reader and writer for the data this app handles: the lines Claude Code prints in
 * stream-json mode and the small payloads sent to the browser.
 *
 * <p>Objects become {@code LinkedHashMap<String, Object>}, arrays become {@code ArrayList<Object>},
 * whole numbers become {@code Long} (or {@code BigInteger} when too large), other numbers become
 * {@code Double}, and JSON null becomes {@code null}.
 *
 * <p>Keeping this in-house means the code doesn't depend on a particular Jackson generation, so it
 * builds unchanged on Spring Boot 4.x (Jackson 3) and 3.5 (Jackson 2). Output is plain ASCII: every
 * other character is written as a {@code \\uXXXX} escape, so the character encoding of the HTTP
 * response can never garble text.
 */
public final class Json {

    private static final int MAX_DEPTH = 200;
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private Json() {
    }

    // ------------------------------------------------------------------ reading

    /**
     * Parses a complete JSON document.
     *
     * @throws IllegalArgumentException if the text isn't valid JSON
     */
    public static Object parse(String text) {
        if (text == null) {
            throw new IllegalArgumentException("No JSON text");
        }
        Parser parser = new Parser(text);
        parser.skipWhitespace();
        Object value = parser.readValue(0);
        parser.skipWhitespace();
        if (!parser.atEnd()) {
            throw parser.error("Unexpected text after the JSON value");
        }
        return value;
    }

    /** Parses a JSON object, or returns {@code null} if the text isn't a valid JSON object. */
    public static Map<String, Object> parseObjectOrNull(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        try {
            Object value = parse(text);
            return value instanceof Map ? asObject(value) : null;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** The value as an object, or an empty map if it isn't one. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> asObject(Object value) {
        return value instanceof Map ? (Map<String, Object>) value : Collections.emptyMap();
    }

    /** The value as an array, or an empty list if it isn't one. */
    @SuppressWarnings("unchecked")
    public static List<Object> asArray(Object value) {
        return value instanceof List ? (List<Object>) value : Collections.emptyList();
    }

    /** {@code parent[key]} as an object, or an empty map. */
    public static Map<String, Object> object(Map<String, Object> parent, String key) {
        return parent == null ? Collections.emptyMap() : asObject(parent.get(key));
    }

    /** {@code parent[key]} as an array, or an empty list. */
    public static List<Object> array(Map<String, Object> parent, String key) {
        return parent == null ? Collections.emptyList() : asArray(parent.get(key));
    }

    /** {@code parent[key]} as a string, or "" if it's missing or not a string. */
    public static String string(Map<String, Object> parent, String key) {
        Object value = parent == null ? null : parent.get(key);
        return value instanceof String s ? s : "";
    }

    /** {@code parent[key]} as a number, or {@code null} if it's missing or not a number. */
    public static Number number(Map<String, Object> parent, String key) {
        Object value = parent == null ? null : parent.get(key);
        return value instanceof Number n ? n : null;
    }

    /** True only if {@code parent[key]} is the JSON value true. */
    public static boolean bool(Map<String, Object> parent, String key) {
        return parent != null && Boolean.TRUE.equals(parent.get(key));
    }

    // ------------------------------------------------------------------ writing

    /**
     * Writes maps, iterables, strings, numbers, booleans and null as JSON. Other objects are
     * written as their {@code toString()} text.
     */
    public static String write(Object value) {
        StringBuilder out = new StringBuilder();
        writeValue(out, value, 0);
        return out.toString();
    }

    private static void writeValue(StringBuilder out, Object value, int depth) {
        if (depth > MAX_DEPTH) {
            throw new IllegalArgumentException("Value is nested too deeply to write as JSON");
        }
        if (value == null) {
            out.append("null");
        } else if (value instanceof CharSequence text) {
            writeString(out, text.toString());
        } else if (value instanceof Boolean flag) {
            out.append(flag.booleanValue());
        } else if (value instanceof Double || value instanceof Float) {
            writeDecimal(out, ((Number) value).doubleValue());
        } else if (value instanceof Number number) {
            out.append(number);
        } else if (value instanceof Map<?, ?> map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (!first) {
                    out.append(',');
                }
                first = false;
                writeString(out, String.valueOf(entry.getKey()));
                out.append(':');
                writeValue(out, entry.getValue(), depth + 1);
            }
            out.append('}');
        } else if (value instanceof Iterable<?> items) {
            out.append('[');
            boolean first = true;
            for (Object item : items) {
                if (!first) {
                    out.append(',');
                }
                first = false;
                writeValue(out, item, depth + 1);
            }
            out.append(']');
        } else if (value instanceof Enum<?> constant) {
            writeString(out, constant.name());
        } else {
            writeString(out, value.toString());
        }
    }

    private static void writeDecimal(StringBuilder out, double number) {
        if (Double.isNaN(number) || Double.isInfinite(number)) {
            out.append("null");
        } else if (number == Math.rint(number) && Math.abs(number) < 1e15) {
            out.append((long) number);
        } else {
            out.append(number);
        }
    }

    private static void writeString(StringBuilder out, String text) {
        out.append('"');
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                default -> {
                    if (c < 0x20 || c > 0x7e) {
                        out.append("\\u")
                                .append(HEX[(c >> 12) & 0xf])
                                .append(HEX[(c >> 8) & 0xf])
                                .append(HEX[(c >> 4) & 0xf])
                                .append(HEX[c & 0xf]);
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
    }

    // ------------------------------------------------------------------ parser

    private static final class Parser {

        private final String text;
        private int pos;

        Parser(String text) {
            this.text = text;
        }

        boolean atEnd() {
            return pos >= text.length();
        }

        IllegalArgumentException error(String message) {
            return new IllegalArgumentException(message + " at position " + pos);
        }

        void skipWhitespace() {
            while (pos < text.length()) {
                char c = text.charAt(pos);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                    pos++;
                } else {
                    return;
                }
            }
        }

        private char peek() {
            return atEnd() ? '\0' : text.charAt(pos);
        }

        Object readValue(int depth) {
            if (depth > MAX_DEPTH) {
                throw error("JSON is nested too deeply");
            }
            if (atEnd()) {
                throw error("Unexpected end of JSON");
            }
            char c = text.charAt(pos);
            switch (c) {
                case '{':
                    return readObject(depth);
                case '[':
                    return readArray(depth);
                case '"':
                    return readString();
                case 't':
                    readWord("true");
                    return Boolean.TRUE;
                case 'f':
                    readWord("false");
                    return Boolean.FALSE;
                case 'n':
                    readWord("null");
                    return null;
                default:
                    if (c == '-' || isDigit(c)) {
                        return readNumber();
                    }
                    throw error("Unexpected character '" + c + "'");
            }
        }

        private Map<String, Object> readObject(int depth) {
            pos++; // {
            Map<String, Object> map = new LinkedHashMap<>();
            skipWhitespace();
            if (peek() == '}') {
                pos++;
                return map;
            }
            while (true) {
                skipWhitespace();
                if (peek() != '"') {
                    throw error("Expected a property name");
                }
                String key = readString();
                skipWhitespace();
                if (peek() != ':') {
                    throw error("Expected ':'");
                }
                pos++;
                skipWhitespace();
                map.put(key, readValue(depth + 1));
                skipWhitespace();
                char c = peek();
                if (c == ',') {
                    pos++;
                } else if (c == '}') {
                    pos++;
                    return map;
                } else {
                    throw error("Expected ',' or '}'");
                }
            }
        }

        private List<Object> readArray(int depth) {
            pos++; // [
            List<Object> list = new ArrayList<>();
            skipWhitespace();
            if (peek() == ']') {
                pos++;
                return list;
            }
            while (true) {
                skipWhitespace();
                list.add(readValue(depth + 1));
                skipWhitespace();
                char c = peek();
                if (c == ',') {
                    pos++;
                } else if (c == ']') {
                    pos++;
                    return list;
                } else {
                    throw error("Expected ',' or ']'");
                }
            }
        }

        private String readString() {
            pos++; // opening quote
            StringBuilder decoded = null;
            int start = pos;
            while (true) {
                if (atEnd()) {
                    throw error("Unterminated string");
                }
                char c = text.charAt(pos);
                if (c == '"') {
                    String result = decoded == null
                            ? text.substring(start, pos)
                            : decoded.append(text, start, pos).toString();
                    pos++;
                    return result;
                }
                if (c == '\\') {
                    if (decoded == null) {
                        decoded = new StringBuilder();
                    }
                    decoded.append(text, start, pos);
                    pos++;
                    if (atEnd()) {
                        throw error("Unterminated escape");
                    }
                    char escape = text.charAt(pos++);
                    switch (escape) {
                        case '"' -> decoded.append('"');
                        case '\\' -> decoded.append('\\');
                        case '/' -> decoded.append('/');
                        case 'b' -> decoded.append('\b');
                        case 'f' -> decoded.append('\f');
                        case 'n' -> decoded.append('\n');
                        case 'r' -> decoded.append('\r');
                        case 't' -> decoded.append('\t');
                        case 'u' -> decoded.append(readHex4());
                        default -> {
                            pos--;
                            throw error("Invalid escape '\\" + escape + "'");
                        }
                    }
                    start = pos;
                    continue;
                }
                if (c < 0x20) {
                    throw error("Control character in string");
                }
                pos++;
            }
        }

        private char readHex4() {
            if (pos + 4 > text.length()) {
                throw error("Incomplete \\u escape");
            }
            int value = 0;
            for (int i = 0; i < 4; i++) {
                int digit = hexValue(text.charAt(pos + i));
                if (digit < 0) {
                    throw error("Invalid \\u escape");
                }
                value = (value << 4) | digit;
            }
            pos += 4;
            return (char) value;
        }

        private Number readNumber() {
            int start = pos;
            if (peek() == '-') {
                pos++;
            }
            if (atEnd()) {
                throw error("Invalid number");
            }
            char first = text.charAt(pos);
            if (first == '0') {
                pos++;
            } else if (isDigit(first)) {
                skipDigits();
            } else {
                throw error("Invalid number");
            }
            boolean whole = true;
            if (peek() == '.') {
                whole = false;
                pos++;
                requireDigit();
                skipDigits();
            }
            if (peek() == 'e' || peek() == 'E') {
                whole = false;
                pos++;
                if (peek() == '+' || peek() == '-') {
                    pos++;
                }
                requireDigit();
                skipDigits();
            }
            String number = text.substring(start, pos);
            if (!whole) {
                return Double.parseDouble(number);
            }
            if (number.length() <= 18) {
                return Long.parseLong(number);
            }
            BigInteger big = new BigInteger(number);
            return big.bitLength() < 64 ? (Number) big.longValue() : big;
        }

        private void requireDigit() {
            if (atEnd() || !isDigit(text.charAt(pos))) {
                throw error("Invalid number");
            }
        }

        private void skipDigits() {
            while (!atEnd() && isDigit(text.charAt(pos))) {
                pos++;
            }
        }

        private void readWord(String word) {
            if (!text.startsWith(word, pos)) {
                throw error("Invalid literal");
            }
            pos += word.length();
        }

        private static boolean isDigit(char c) {
            return c >= '0' && c <= '9';
        }

        private static int hexValue(char c) {
            if (c >= '0' && c <= '9') {
                return c - '0';
            }
            if (c >= 'a' && c <= 'f') {
                return c - 'a' + 10;
            }
            if (c >= 'A' && c <= 'F') {
                return c - 'A' + 10;
            }
            return -1;
        }
    }
}
