package com.example.claudeconsole.claude;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.example.claudeconsole.json.Json;

/**
 * Turns the lines Claude Code prints with {@code --output-format stream-json --verbose
 * --include-partial-messages} into the events the browser understands:
 *
 * <ul>
 *   <li>{@code init}: the model, the conversation ID and any tools that are still enabled</li>
 *   <li>{@code delta}: the next piece of answer text</li>
 *   <li>{@code retry}: Claude Code is retrying an API request, with the reason</li>
 *   <li>{@code result}: the final answer, or the error that ended the run</li>
 * </ul>
 *
 * Other lines (full assistant messages, tool activity, anything that isn't JSON) are skipped.
 * One mapper is used for one run.
 */
public final class StreamEventMapper {

    /** Built-in tools that can run commands, change files or reach the network. */
    static final Set<String> RISKY_TOOLS = Set.of(
            "Bash", "PowerShell", "Edit", "MultiEdit", "Write", "NotebookEdit", "WebFetch", "WebSearch");

    private boolean textSent;
    private boolean resultSeen;
    private boolean resultIsError;
    private String resultText = "";
    private String sessionId = "";
    private String model = "";
    private String lastRetryError = "";

    /** Maps one output line to zero or more browser events. */
    public List<UiEvent> map(String line) {
        if (line == null || line.isBlank()) {
            return List.of();
        }
        Map<String, Object> message = Json.parseObjectOrNull(line.strip());
        if (message == null) {
            return List.of();
        }
        String id = Json.string(message, "session_id");
        if (!id.isEmpty()) {
            sessionId = id;
        }
        switch (Json.string(message, "type")) {
            case "system":
                return mapSystem(message);
            case "stream_event":
                return fromSubagent(message) ? List.of() : mapStreamEvent(Json.object(message, "event"));
            case "result":
                return mapResult(message);
            default:
                return List.of();
        }
    }

    public boolean resultSeen() {
        return resultSeen;
    }

    public boolean resultIsError() {
        return resultIsError;
    }

    public String resultText() {
        return resultText;
    }

    public String sessionId() {
        return sessionId;
    }

    public String model() {
        return model;
    }

    /** Error category of the most recent API retry, or "". */
    public String lastRetryError() {
        return lastRetryError;
    }

    private List<UiEvent> mapSystem(Map<String, Object> message) {
        String subtype = Json.string(message, "subtype");
        if ("init".equals(subtype)) {
            model = Json.string(message, "model");
            List<String> tools = new ArrayList<>();
            for (Object tool : Json.array(message, "tools")) {
                if (tool instanceof String name) {
                    tools.add(name);
                }
            }
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("model", model);
            data.put("sessionId", sessionId);
            data.put("tools", tools);
            data.put("riskyTools", tools.stream().filter(StreamEventMapper::isRisky).toList());
            return List.of(new UiEvent("init", data));
        }
        if ("api_retry".equals(subtype)) {
            String error = Json.string(message, "error");
            lastRetryError = error;
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("attempt", Json.number(message, "attempt"));
            data.put("maxRetries", Json.number(message, "max_retries"));
            data.put("delayMs", Json.number(message, "retry_delay_ms"));
            data.put("httpStatus", Json.number(message, "error_status"));
            data.put("error", error.isEmpty() ? "unknown" : error);
            return List.of(new UiEvent("retry", data));
        }
        return List.of();
    }

    private List<UiEvent> mapStreamEvent(Map<String, Object> event) {
        if ("content_block_start".equals(Json.string(event, "type"))) {
            boolean textBlock = "text".equals(Json.string(Json.object(event, "content_block"), "type"));
            // A later text block (for example after a tool call) starts a new paragraph.
            return textBlock && textSent ? List.of(delta("\n\n")) : List.of();
        }
        Map<String, Object> delta = Json.object(event, "delta");
        if ("text_delta".equals(Json.string(delta, "type"))) {
            String text = Json.string(delta, "text");
            if (text.isEmpty()) {
                return List.of();
            }
            textSent = true;
            return List.of(delta(text));
        }
        return List.of();
    }

    private List<UiEvent> mapResult(Map<String, Object> message) {
        String subtype = Json.string(message, "subtype");
        boolean error = Json.bool(message, "is_error") || (!subtype.isEmpty() && !"success".equals(subtype));
        String text = Json.string(message, "result");
        if (error && text.isBlank()) {
            text = describeErrorSubtype(subtype);
        }
        resultSeen = true;
        resultIsError = error;
        resultText = text;

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("text", text);
        data.put("isError", error);
        data.put("subtype", subtype);
        data.put("sessionId", sessionId);
        data.put("model", model);
        data.put("costUsd", Json.number(message, "total_cost_usd"));
        data.put("durationMs", Json.number(message, "duration_ms"));
        data.put("numTurns", Json.number(message, "num_turns"));
        return List.of(new UiEvent("result", data));
    }

    static String describeErrorSubtype(String subtype) {
        switch (subtype) {
            case "error_max_turns":
                return "Claude Code stopped because the run reached its turn limit.";
            case "error_during_execution":
                return "Claude Code reported an error while answering. Check the app log for details.";
            case "":
                return "Claude Code reported an error without details. Check the app log.";
            default:
                return "Claude Code ended the run with \"" + subtype + "\".";
        }
    }

    private static boolean fromSubagent(Map<String, Object> message) {
        return message.get("parent_tool_use_id") instanceof String id && !id.isEmpty();
    }

    private static boolean isRisky(String tool) {
        return RISKY_TOOLS.contains(tool) || tool.startsWith("mcp__");
    }

    private static UiEvent delta(String text) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("text", text);
        return new UiEvent("delta", data);
    }
}
