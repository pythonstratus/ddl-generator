package com.example.claudeconsole.claude;

/** Outcome of a short command such as {@code claude --version}. */
public record CommandResult(int exitCode, String stdout, String stderr, boolean timedOut) {
}
