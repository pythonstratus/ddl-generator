package com.example.claudeconsole.web;

import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.claudeconsole.claude.ClaudeRunner;
import com.example.claudeconsole.config.ClaudeProperties;
import com.example.claudeconsole.status.ClaudeStatusService;

/** Connection status for the lights at the top of the page. */
@RestController
@RequestMapping("/api/status")
public class StatusController {

    private final ClaudeStatusService status;
    private final ClaudeRunner runner;
    private final ClaudeProperties props;

    public StatusController(ClaudeStatusService status, ClaudeRunner runner, ClaudeProperties props) {
        this.status = status;
        this.runner = runner;
        this.props = props;
    }

    /** The latest results. Cheap: the checks themselves run in the background. */
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> current() {
        return JsonResponses.ok(snapshot());
    }

    /** Runs the checks now (the "Check again" button), then returns the results. */
    @PostMapping(value = "/refresh", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> refresh() {
        status.refresh(true);
        return JsonResponses.ok(snapshot());
    }

    private Map<String, Object> snapshot() {
        Map<String, Object> data = status.snapshot();
        data.put("activeRuns", runner.activeRuns());
        data.put("maxConcurrentRuns", props.getMaxConcurrentRuns());
        return data;
    }
}
