package com.example.claudeconsole.web;

import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.example.claudeconsole.json.Json;

/** Builds JSON responses with the app's own writer, so they look the same on every Spring Boot version. */
final class JsonResponses {

    private JsonResponses() {
    }

    static ResponseEntity<String> ok(Object body) {
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .cacheControl(CacheControl.noStore())
                .body(Json.write(body));
    }
}
