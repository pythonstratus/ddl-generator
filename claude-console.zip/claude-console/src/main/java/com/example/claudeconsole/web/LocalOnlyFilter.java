package com.example.claudeconsole.web;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.claudeconsole.config.ConsoleProperties;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Refuses requests that weren't addressed to this computer, and requests sent by other web sites,
 * and adds the {@link SecurityHeaders} to everything else.
 *
 * <p>The app is bound to 127.0.0.1, but a web page you visit could still try to reach it through
 * your browser, either directly (cross-site request) or through a DNS name that resolves to
 * 127.0.0.1 (DNS rebinding). Checking the Host and Origin headers blocks both.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class LocalOnlyFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(LocalOnlyFilter.class);
    private static final String REFUSED_BODY = "{\"error\":\"This app only answers requests addressed to this "
            + "computer. To use another host name, add it to console.allowed-hosts.\"}";

    private final ConsoleProperties console;

    public LocalOnlyFilter(ConsoleProperties console) {
        this.console = console;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String hostHeader = request.getHeader("Host");
        if (!HostCheck.isAllowed(HostCheck.hostFromHeader(hostHeader), console.getAllowedHosts())) {
            refuse(response, "Host", hostHeader);
            return;
        }
        String origin = request.getHeader("Origin");
        if (origin != null && !HostCheck.isAllowed(HostCheck.hostFromOrigin(origin), console.getAllowedHosts())) {
            refuse(response, "Origin", origin);
            return;
        }
        SecurityHeaders.ALL.forEach(response::setHeader);
        chain.doFilter(request, response);
    }

    private static void refuse(HttpServletResponse response, String header, String value) throws IOException {
        log.warn("Refused a request with {} header {}", header, HostCheck.forLog(value));
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType("application/json");
        response.getWriter().write(REFUSED_BODY);
    }
}
