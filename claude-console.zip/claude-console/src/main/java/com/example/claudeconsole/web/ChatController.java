package com.example.claudeconsole.web;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.example.claudeconsole.claude.ClaudeRunner;
import com.example.claudeconsole.claude.EventSink;
import com.example.claudeconsole.claude.UiEvent;
import com.example.claudeconsole.config.ClaudeProperties;
import com.example.claudeconsole.json.Json;

/**
 * Receives questions and streams the answers back as server-sent events:
 * {@code start}, {@code init}, {@code delta}..., {@code retry}, {@code result} or {@code error},
 * and finally {@code done}.
 */
@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ClaudeRunner runner;
    private final ClaudeProperties props;

    public ChatController(ClaudeRunner runner, ClaudeProperties props) {
        this.runner = runner;
        this.props = props;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public SseEmitter ask(@RequestBody String body) {
        // Allow a minute beyond the run's own timeout so the run always ends first.
        SseEmitter emitter = new SseEmitter(TimeUnit.SECONDS.toMillis(props.getTimeoutSeconds() + 60L));
        EventSink sink = event -> emitter.send(SseEmitter.event()
                .name(event.name())
                .data(Json.write(event.data()), MediaType.APPLICATION_JSON));

        ChatRequest request;
        try {
            request = ChatRequest.fromJson(body, props.getMaxPromptChars());
        } catch (IllegalArgumentException e) {
            return refuse(emitter, sink, "invalid_request", e.getMessage());
        }

        String runId = runner.newRunId();
        emitter.onTimeout(() -> runner.cancel(runId));
        emitter.onError(error -> runner.cancel(runId));
        try {
            runner.start(runId, request.prompt(), request.sessionId(), sink, () -> complete(emitter));
        } catch (RejectedExecutionException e) {
            return refuse(emitter, sink, "shutting_down", "The app is shutting down. Start it again, then retry.");
        }
        return emitter;
    }

    @PostMapping(value = "/{runId}/cancel", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> cancel(@PathVariable("runId") String runId) {
        return JsonResponses.ok(Map.of("stopped", runner.cancel(runId)));
    }

    private static SseEmitter refuse(SseEmitter emitter, EventSink sink, String code, String message) {
        Map<String, Object> error = new LinkedHashMap<>();
        error.put("code", code);
        error.put("message", message);
        Map<String, Object> done = new LinkedHashMap<>();
        done.put("runId", null);
        done.put("stopped", false);
        done.put("timedOut", false);
        done.put("resetConversation", false);
        try {
            sink.send(new UiEvent("error", error));
            sink.send(new UiEvent("done", done));
        } catch (IOException | RuntimeException ignored) {
            // The browser is already gone.
        }
        complete(emitter);
        return emitter;
    }

    private static void complete(SseEmitter emitter) {
        try {
            emitter.complete();
        } catch (RuntimeException ignored) {
            // Already completed, or the browser disconnected.
        }
    }
}
