// Page logic for Claude console. Plain JavaScript modules, no build step and no npm packages.

import { cancelRun, getStatus, refreshStatus, streamChat } from './api.js';
import { copyText } from './clipboard.js';
import { describeRetry, formatAgo, formatCost, formatSeconds } from './format.js';
import { renderMarkdown } from './markdown.js';
import { highlight } from './syntax.js';

const POLL_MS = 5000;

const RESET_NOTICES = {
  stopped: 'Stopped. Your next question starts a new conversation.',
  timeout: 'That answer took too long and was stopped. Your next question starts a new conversation.',
  resume_failed: "This conversation couldn't be continued, so your next question starts a new one.",
};

const LAMPS = { OK: 'ok', WARN: 'warn', ERROR: 'error', UNKNOWN: 'idle' };

const CHECK_MODES = { 'auth-status': 'claude auth status', prompt: 'Test prompt', none: 'Off' };

const byId = (id) => document.getElementById(id);
const ui = {
  thread: byId('thread'),
  intro: byId('intro'),
  notice: byId('notice'),
  end: byId('thread-end'),
  composer: byId('composer'),
  question: byId('question'),
  ask: byId('ask'),
  stop: byId('stop'),
  hint: byId('hint'),
  newConversation: byId('new-conversation'),
  toggleDetails: byId('toggle-details'),
  checkAgain: byId('check-again'),
  details: byId('status-details'),
  offlineCallout: byId('offline-callout'),
  attentionCallout: byId('attention-callout'),
  announcer: byId('announcer'),
};

const state = {
  status: null,
  serverUp: null, // null until the first status request finishes
  checking: false,
  busy: false,
  sessionId: null,
  run: null,
  turns: 0,
  detailsOpen: false,
  followOutput: true,
};

// ------------------------------------------------------------------ helpers

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = text;
  return node;
}

function showText(node, text) {
  node.textContent = text || '';
  node.hidden = !text;
}

function announce(text) {
  ui.announcer.textContent = text;
}

function setNotice(text) {
  showText(ui.notice, text);
}

function scrollToEnd() {
  if (state.followOutput) ui.end.scrollIntoView({ block: 'end' });
}

function autoSize() {
  const box = ui.question;
  box.style.height = 'auto';
  box.style.height = `${Math.min(box.scrollHeight, 240)}px`;
}

function copyButton(label, getText) {
  const button = el('button', 'quiet-button small', label);
  button.type = 'button';
  button.addEventListener('click', async () => {
    const copied = await copyText(getText());
    button.textContent = copied ? 'Copied' : 'Copy failed';
    setTimeout(() => {
      button.textContent = label;
    }, 1600);
  });
  return button;
}

function codeBlock(code, language) {
  const block = el('div', 'code-block');
  const bar = el('div', 'code-bar');
  bar.append(el('span', null, language || 'Code'), copyButton('Copy code', () => code));
  const pre = el('pre');
  const element = el('code', language ? `hljs language-${language}` : null);
  element.append(highlight(code, language));
  pre.append(element);
  block.append(bar, pre);
  return block;
}

// ------------------------------------------------------------------ status lights

function setLight(key, lamp, value, when = '', pulse = false) {
  const light = document.querySelector(`.light[data-light="${key}"]`);
  light.querySelector('.lamp').className = `lamp lamp-${lamp}${pulse ? ' is-pulsing' : ''}`;
  const valueNode = light.querySelector('.light-value');
  valueNode.textContent = value;
  if (when) valueNode.append(el('span', 'light-when', ` ${when}`));
}

function lampFor(check) {
  return LAMPS[check?.state] || 'idle';
}

function renderStatus() {
  const { status, serverUp, busy } = state;
  const checking = state.checking || Boolean(status?.checking);
  const offline = serverUp === false;
  const known = Boolean(status) && !offline;

  setLight(
    'server',
    serverUp === null ? 'idle' : serverUp ? 'ok' : 'error',
    serverUp === null ? 'Connecting' : serverUp ? 'Connected' : 'Not reachable',
    '',
    serverUp === null,
  );
  setLight('cli', known ? lampFor(status.cli) : 'idle', known ? status.cli.summary : 'Unknown', '', known && checking);
  setLight('signin', known ? lampFor(status.signIn) : 'idle', known ? status.signIn.summary : 'Unknown', '',
    known && checking);
  if (busy) {
    setLight('last', 'busy', 'Answering', '', true);
  } else {
    const when = known && status.lastRun.checkedAt ? formatAgo(status.lastRun.checkedAt) : '';
    setLight('last', known ? lampFor(status.lastRun) : 'idle', known ? status.lastRun.summary : 'Unknown', when);
  }

  ui.checkAgain.disabled = checking || offline;
  ui.checkAgain.textContent = checking ? 'Checking\u2026' : 'Check again';
  ui.offlineCallout.hidden = !offline;
  ui.attentionCallout.hidden = offline || !(status && (status.cli?.state === 'ERROR' || status.signIn?.state === 'ERROR'));
  if (state.detailsOpen) renderDetails();
  renderComposer();
}

function renderDetails() {
  const { status } = state;
  if (state.serverUp === false) {
    const text = el('p');
    text.append("The app server isn't answering. If the terminal that ran ", el('code', null, 'java -jar'),
      ' was closed, start the app again and reload this page.');
    ui.details.replaceChildren(text);
    return;
  }
  if (!status) {
    ui.details.replaceChildren(el('p', null, 'Waiting for the first status report.'));
    return;
  }
  const list = el('dl');
  const row = (label, ...content) => {
    const line = el('div', 'detail-row');
    const value = el('dd');
    value.append(...content);
    line.append(el('dt', null, label), value);
    list.append(line);
  };
  const checks = [
    ['Claude Code', status.cli, 'Checked'],
    ['Sign-in', status.signIn, 'Checked'],
    ['Last question', status.lastRun, 'Finished'],
  ];
  for (const [label, check, timeLabel] of checks) {
    const parts = [el('span', 'detail-summary', check.summary)];
    if (check.detail) parts.push(el('span', 'detail-text', check.detail));
    if (check.checkedAt) parts.push(el('span', 'detail-time', `${timeLabel} ${formatAgo(check.checkedAt)}`));
    row(label, ...parts);
  }
  row('Model', status.model || status.configuredModel || 'Not known until the first answer');
  row('Command', el('code', null, status.command));
  row('Working folder', el('code', null, status.workingDir));
  row('Sign-in check', CHECK_MODES[status.checkMode] || status.checkMode);
  row('Questions running', `${status.activeRuns} of ${status.maxConcurrentRuns}`);
  ui.details.replaceChildren(list);
}

async function loadStatus() {
  try {
    state.status = await getStatus();
    state.serverUp = true;
  } catch {
    state.serverUp = false;
  }
  renderStatus();
}

async function checkNow() {
  state.checking = true;
  renderStatus();
  try {
    state.status = await refreshStatus();
    state.serverUp = true;
  } catch {
    state.serverUp = false;
  } finally {
    state.checking = false;
    renderStatus();
  }
}

// ------------------------------------------------------------------ composer

function renderComposer() {
  const offline = state.serverUp === false;
  ui.ask.hidden = state.busy;
  ui.stop.hidden = !state.busy;
  ui.ask.disabled = offline || !ui.question.value.trim();
  ui.question.placeholder = state.sessionId ? 'Type a follow-up question' : 'Type your question';
  let hint = 'Enter asks. Shift+Enter adds a line.';
  if (offline) hint = "The app server isn't reachable.";
  else if (state.busy) hint = 'Stop ends this answer. Your next question then starts a new conversation.';
  else if (state.sessionId) hint = 'Follow-up questions continue this conversation.';
  ui.hint.textContent = hint;
  ui.newConversation.disabled = state.busy || (state.turns === 0 && !state.sessionId);
}

// ------------------------------------------------------------------ messages

function addQuestion(text) {
  const turn = el('article', 'turn turn-question');
  turn.setAttribute('aria-label', 'Your question');
  turn.append(el('p', 'question-text', text));
  ui.thread.insertBefore(turn, ui.notice);
}

/** One answer on the page. Call update() with changed fields; it redraws what changed. */
class Answer {
  constructor() {
    this.text = '';
    this.state = 'waiting'; // waiting | streaming | done | error | stopped
    this.meta = {};
    this.retry = null;
    this.error = '';
    this.warning = '';
    this.drawnText = null;
    this.drawnFooter = false;

    this.root = el('article', 'turn turn-answer');
    this.root.setAttribute('aria-label', 'Answer');
    this.warningNode = el('p', 'callout callout-warn');
    this.pendingNode = el('p', 'pending');
    const mark = el('span', 'pending-mark');
    mark.setAttribute('aria-hidden', 'true');
    this.pendingNode.append(mark, 'Waiting for Claude Code');
    this.retryNode = el('p', 'callout callout-warn');
    this.bodyNode = el('div', 'answer');
    this.errorNode = el('p', 'callout callout-error');
    this.errorNode.setAttribute('role', 'alert');
    this.stoppedNode = el('p', 'stopped-note', 'You stopped this answer.');
    this.footerNode = el('footer', 'answer-footer');
    this.root.append(this.warningNode, this.pendingNode, this.retryNode, this.bodyNode, this.errorNode,
      this.stoppedNode, this.footerNode);
    ui.thread.insertBefore(this.root, ui.notice);
    this.draw();
  }

  update(changes) {
    Object.assign(this, changes);
    this.draw();
  }

  draw() {
    const waiting = this.state === 'waiting';
    const streaming = this.state === 'streaming';
    const finished = this.state === 'done' || this.state === 'error' || this.state === 'stopped';
    this.root.setAttribute('aria-busy', String(waiting || streaming));

    showText(this.warningNode, this.warning);
    this.pendingNode.hidden = !(waiting && !this.retry);

    if (this.retry) {
      const { error, attempt, maxRetries } = this.retry;
      const count = attempt ? ` (attempt ${attempt}${maxRetries ? ` of ${maxRetries}` : ''})` : '';
      showText(this.retryNode, `Retrying because of ${describeRetry(error)}${count}.`);
    } else {
      showText(this.retryNode, '');
    }

    if (this.text !== this.drawnText) {
      this.bodyNode.replaceChildren(renderMarkdown(this.text, { codeBlock }));
      this.drawnText = this.text;
    }
    this.bodyNode.hidden = !this.text;
    this.bodyNode.classList.toggle('is-streaming', streaming);

    showText(this.errorNode, this.error);
    this.stoppedNode.hidden = this.state !== 'stopped';

    const showFooter = finished && Boolean(this.text || this.meta.model);
    this.footerNode.hidden = !showFooter;
    if (showFooter && !this.drawnFooter) {
      const parts = [];
      if (this.meta.model) parts.push(el('span', null, this.meta.model));
      if (this.meta.durationMs != null) parts.push(el('span', null, formatSeconds(this.meta.durationMs)));
      if (this.meta.costUsd != null) {
        const cost = el('span', null, `est. ${formatCost(this.meta.costUsd)}`);
        cost.title = 'Cost estimate reported by Claude Code';
        parts.push(cost);
      }
      if (this.text) parts.push(copyButton('Copy answer', () => this.text));
      this.footerNode.replaceChildren(...parts);
      this.drawnFooter = true;
    }
  }
}

// ------------------------------------------------------------------ asking

async function send(rawText) {
  const prompt = rawText.trim();
  if (!prompt || state.busy || state.serverUp === false) return;

  ui.intro.hidden = true;
  addQuestion(prompt);
  const answer = new Answer();
  state.turns += 1;
  ui.question.value = '';
  autoSize();
  setNotice('');
  announce('');
  state.busy = true;
  state.followOutput = true;
  renderStatus();
  scrollToEnd();

  const controller = new AbortController();
  const run = { id: null, controller, stopped: false };
  state.run = run;

  // Text arrives in many small pieces; draw at most once per frame.
  let pending = '';
  let frame = 0;
  const flush = () => {
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
    if (!pending) return;
    const chunk = pending;
    pending = '';
    answer.update({ text: answer.text + chunk, state: 'streaming', retry: null });
    scrollToEnd();
  };

  let settled = false;
  let resetReason = null;

  const onEvent = (name, data) => {
    switch (name) {
      case 'start':
        run.id = data.runId;
        break;
      case 'init':
        if (data.sessionId) state.sessionId = data.sessionId;
        answer.update({
          meta: { ...answer.meta, model: data.model },
          warning: data.riskyTools?.length
            ? `Tools are turned on for this question (${data.riskyTools.join(', ')}), so Claude could run `
              + 'commands or change files. Check claude.disallowed-tools in application.yml.'
            : '',
        });
        break;
      case 'delta':
        pending += data.text;
        if (!frame) frame = requestAnimationFrame(flush);
        break;
      case 'retry':
        flush();
        answer.update({ retry: data });
        break;
      case 'result':
        flush();
        settled = true;
        if (data.sessionId) state.sessionId = data.sessionId;
        answer.update({
          text: data.isError ? answer.text : data.text || answer.text,
          state: data.isError ? 'error' : 'done',
          error: data.isError ? data.text : '',
          retry: null,
          meta: {
            ...answer.meta,
            model: data.model || answer.meta.model,
            costUsd: data.costUsd,
            durationMs: data.durationMs,
          },
        });
        announce(data.isError ? 'Claude Code reported an error.' : 'Answer ready.');
        break;
      case 'error':
        flush();
        settled = true;
        answer.update({ state: 'error', error: data.message, retry: null });
        announce('The question failed.');
        break;
      case 'done':
        flush();
        if (data.resetConversation) resetReason = data.resetReason || 'stopped';
        break;
      default:
        break;
    }
    scrollToEnd();
  };

  try {
    await streamChat({ prompt, sessionId: state.sessionId }, onEvent, controller.signal);
    flush();
    if (!settled && !run.stopped) {
      answer.update({ state: 'error', error: 'The answer ended before Claude Code finished. Try asking again.' });
    }
  } catch (error) {
    flush();
    if (!run.stopped && error.name !== 'AbortError') {
      answer.update({
        state: 'error',
        error: `Couldn't reach the app server (${error.message}). Check that it's still running, then try again.`,
      });
      state.serverUp = false;
    }
  } finally {
    if (run.stopped) {
      if (answer.state !== 'done' && answer.state !== 'error') answer.update({ state: 'stopped', retry: null });
      resetReason = resetReason || 'stopped';
      announce('Stopped.');
    }
    if (resetReason) {
      state.sessionId = null;
      setNotice(RESET_NOTICES[resetReason] || RESET_NOTICES.stopped);
    }
    state.run = null;
    state.busy = false;
    renderStatus();
    loadStatus();
    ui.question.focus();
    scrollToEnd();
  }
}

function stop() {
  const { run } = state;
  if (!run || run.stopped) return;
  run.stopped = true;
  if (run.id) cancelRun(run.id).catch(() => {});
  run.controller.abort();
}

function newConversation() {
  if (state.busy) return;
  ui.thread.querySelectorAll('.turn').forEach((turn) => turn.remove());
  state.turns = 0;
  state.sessionId = null;
  setNotice('');
  announce('');
  ui.intro.hidden = false;
  renderComposer();
  ui.question.focus();
}

// ------------------------------------------------------------------ wiring

ui.composer.addEventListener('submit', (event) => {
  event.preventDefault();
  send(ui.question.value);
});

ui.question.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    send(ui.question.value);
  }
});

ui.question.addEventListener('input', () => {
  autoSize();
  renderComposer();
});

ui.stop.addEventListener('click', stop);
ui.newConversation.addEventListener('click', newConversation);
ui.checkAgain.addEventListener('click', checkNow);

ui.toggleDetails.addEventListener('click', () => {
  state.detailsOpen = !state.detailsOpen;
  ui.toggleDetails.setAttribute('aria-expanded', String(state.detailsOpen));
  ui.toggleDetails.textContent = state.detailsOpen ? 'Hide details' : 'Details';
  ui.details.hidden = !state.detailsOpen;
  if (state.detailsOpen) renderDetails();
});

document.querySelectorAll('[data-example]').forEach((button) => {
  button.addEventListener('click', () => {
    ui.question.value = button.textContent.trim();
    autoSize();
    renderComposer();
    ui.question.focus();
  });
});

window.addEventListener('scroll', () => {
  const root = document.documentElement;
  state.followOutput = root.scrollHeight - window.scrollY - window.innerHeight < 160;
}, { passive: true });

loadStatus();
setInterval(loadStatus, POLL_MS);
renderComposer();
