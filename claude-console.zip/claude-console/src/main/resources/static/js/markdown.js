// Markdown to DOM, written for this page so it needs no npm packages.
//
// It covers what Claude usually writes: headings, paragraphs, bold, italic, strikethrough, inline
// code, links, nested and numbered lists, task lists, block quotes, fenced code blocks, tables and
// horizontal rules.
//
// Safety: the renderer only creates DOM nodes and sets text through text nodes. It never parses
// HTML, so HTML inside an answer is shown as text. Links are limited to http, https, mailto and
// relative addresses, and images are shown as links instead of being loaded.

const FENCE_OPEN = /^( {0,3})(`{3,}|~{3,})[ \t]*([^\s`]*)[^`]*$/;
const FENCE_CLOSE = /^ {0,3}(`{3,}|~{3,})[ \t]*$/;
const HEADING = /^ {0,3}(#{1,6})(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*$/;
const RULE = /^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$/;
const QUOTE = /^ {0,3}> ?(.*)$/;
const LIST_ITEM = /^( {0,3})([-*+]|\d{1,9}[.)])(?:([ \t]+)(.*))?$/;
const TABLE_DIVIDER = /^ {0,3}\|?[ \t]*:?-+:?[ \t]*(?:\|[ \t]*:?-+:?[ \t]*)*\|?[ \t]*$/;
const TASK = /^\[([ xX])\][ \t]+/;
const ESCAPABLE = /[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/;
const WORD_CHAR = /[\p{L}\p{N}]/u;
const SPACE = /\s/;
const MAX_DEPTH = 24;

/**
 * Renders Markdown into a DocumentFragment.
 * options.codeBlock(code, language) may return the element to use for each fenced code block.
 */
export function renderMarkdown(source, options = {}) {
  const fragment = document.createDocumentFragment();
  const lines = String(source ?? '').replace(/\r\n?/g, '\n').split('\n');
  renderBlocks(lines, fragment, options, 0);
  return fragment;
}

// ------------------------------------------------------------------ blocks

function renderBlocks(lines, parent, options, depth) {
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i += 1;
      continue;
    }
    let match = FENCE_OPEN.exec(line);
    if (match) {
      i = renderFence(lines, i, match, parent, options);
      continue;
    }
    match = HEADING.exec(line);
    if (match) {
      const heading = el(`h${match[1].length}`);
      renderInline(match[2] || '', heading);
      parent.append(heading);
      i += 1;
      continue;
    }
    if (RULE.test(line)) {
      parent.append(el('hr'));
      i += 1;
      continue;
    }
    if (depth < MAX_DEPTH && QUOTE.test(line)) {
      i = renderQuote(lines, i, parent, options, depth);
      continue;
    }
    if (isTableStart(lines, i)) {
      i = renderTable(lines, i, parent);
      continue;
    }
    if (depth < MAX_DEPTH && LIST_ITEM.test(line)) {
      i = renderList(lines, i, parent, options, depth);
      continue;
    }
    i = renderParagraph(lines, i, parent);
  }
}

function startsBlock(line) {
  return FENCE_OPEN.test(line) || HEADING.test(line) || RULE.test(line) || QUOTE.test(line) || LIST_ITEM.test(line);
}

function renderParagraph(lines, start, parent) {
  const text = [lines[start].trimStart()];
  let i = start + 1;
  while (i < lines.length && lines[i].trim() && !startsBlock(lines[i]) && !isTableStart(lines, i)) {
    text.push(lines[i].trimStart());
    i += 1;
  }
  const paragraph = el('p');
  renderInline(text.join('\n'), paragraph);
  parent.append(paragraph);
  return i;
}

function renderFence(lines, start, match, parent, options) {
  const indent = match[1].length;
  const fence = match[2];
  const language = match[3] || '';
  const body = [];
  let i = start + 1;
  // An unclosed fence runs to the end, which is right while an answer is still streaming.
  while (i < lines.length) {
    const close = FENCE_CLOSE.exec(lines[i]);
    if (close && close[1][0] === fence[0] && close[1].length >= fence.length) {
      i += 1;
      break;
    }
    body.push(indent ? lines[i].replace(new RegExp(`^ {0,${indent}}`), '') : lines[i]);
    i += 1;
  }
  const code = body.join('\n');
  parent.append(options.codeBlock ? options.codeBlock(code, language) : plainCodeBlock(code, language));
  return i;
}

function plainCodeBlock(code, language) {
  const pre = el('pre');
  const element = el('code', language ? `language-${language}` : null);
  element.textContent = code;
  pre.append(element);
  return pre;
}

function renderQuote(lines, start, parent, options, depth) {
  const inner = [];
  let i = start;
  while (i < lines.length) {
    const match = QUOTE.exec(lines[i]);
    if (match) {
      inner.push(match[1]);
      i += 1;
      continue;
    }
    // A plain line right after quoted text continues the quoted paragraph.
    const continues = lines[i].trim() !== '' && inner.length > 0 && inner[inner.length - 1].trim() !== ''
      && !startsBlock(lines[i]);
    if (!continues) break;
    inner.push(lines[i]);
    i += 1;
  }
  const quote = el('blockquote');
  renderBlocks(inner, quote, options, depth + 1);
  parent.append(quote);
  return i;
}

function isTableStart(lines, i) {
  return i + 1 < lines.length
    && lines[i].includes('|')
    && lines[i + 1].includes('|')
    && TABLE_DIVIDER.test(lines[i + 1])
    && splitRow(lines[i]).length === splitRow(lines[i + 1]).length;
}

function splitRow(line) {
  let row = line.trim();
  if (row.startsWith('|')) row = row.slice(1);
  if (row.endsWith('|') && !row.endsWith('\\|')) row = row.slice(0, -1);
  const cells = [];
  let cell = '';
  for (let k = 0; k < row.length; k += 1) {
    const c = row[k];
    if (c === '\\' && row[k + 1] === '|') {
      cell += '|';
      k += 1;
    } else if (c === '|') {
      cells.push(cell.trim());
      cell = '';
    } else {
      cell += c;
    }
  }
  cells.push(cell.trim());
  return cells;
}

function renderTable(lines, start, parent) {
  const header = splitRow(lines[start]);
  const aligns = splitRow(lines[start + 1]).map((cell) => {
    const left = cell.startsWith(':');
    const right = cell.endsWith(':');
    if (left && right) return 'center';
    if (right) return 'right';
    return left ? 'left' : '';
  });
  const table = el('table');
  const head = el('thead');
  const headRow = el('tr');
  header.forEach((text, k) => headRow.append(tableCell('th', text, aligns[k])));
  head.append(headRow);
  table.append(head);

  const body = el('tbody');
  let i = start + 2;
  while (i < lines.length && lines[i].trim() && lines[i].includes('|') && !startsBlock(lines[i])) {
    const cells = splitRow(lines[i]);
    const row = el('tr');
    header.forEach((_, k) => row.append(tableCell('td', cells[k] ?? '', aligns[k])));
    body.append(row);
    i += 1;
  }
  if (body.childNodes.length) table.append(body);

  const scroller = el('div', 'table-scroll');
  scroller.append(table);
  parent.append(scroller);
  return i;
}

function tableCell(tag, text, align) {
  const cell = el(tag);
  if (align) cell.style.textAlign = align;
  renderInline(text, cell);
  return cell;
}

function expandLeadingTabs(line) {
  const lead = /^[ \t]+/.exec(line);
  if (!lead || !lead[0].includes('\t')) return line;
  let width = 0;
  for (const c of lead[0]) width = c === '\t' ? width + 4 - (width % 4) : width + 1;
  return ' '.repeat(width) + line.slice(lead[0].length);
}

function renderList(lines, start, parent, options, depth) {
  const first = LIST_ITEM.exec(lines[start]);
  const ordered = /\d/.test(first[2]);
  const delimiter = first[2].slice(-1);
  const list = el(ordered ? 'ol' : 'ul');
  if (ordered) {
    const number = parseInt(first[2], 10);
    if (number !== 1) list.setAttribute('start', String(number));
  }

  let i = start;
  while (i < lines.length) {
    const match = LIST_ITEM.exec(lines[i]);
    if (!match || /\d/.test(match[2]) !== ordered || match[2].slice(-1) !== delimiter) break;
    const gap = match[3] ? match[3].length : 1;
    const width = match[1].length + match[2].length + Math.min(gap, 4);
    const body = [match[4] ?? ''];
    let loose = false;
    let afterBlank = false;
    i += 1;
    while (i < lines.length) {
      const line = expandLeadingTabs(lines[i]);
      if (!line.trim()) {
        body.push('');
        afterBlank = true;
        i += 1;
        continue;
      }
      const indent = line.length - line.trimStart().length;
      if (indent >= width) {
        body.push(line.slice(width));
        if (afterBlank) loose = true;
        afterBlank = false;
        i += 1;
        continue;
      }
      if (afterBlank || startsBlock(line) || isTableStart(lines, i)) break;
      body.push(line.trimStart()); // a wrapped line of the item's text
      i += 1;
    }
    while (body.length > 1 && !body[body.length - 1].trim()) body.pop();
    list.append(renderListItem(body, loose, options, depth));
  }
  parent.append(list);
  return i;
}

function renderListItem(body, loose, options, depth) {
  const item = el('li');
  const task = TASK.exec(body[0]);
  if (task) {
    const box = el('input');
    box.type = 'checkbox';
    box.disabled = true;
    if (task[1] !== ' ') box.setAttribute('checked', '');
    item.className = 'task';
    item.append(box);
    body[0] = body[0].slice(task[0].length);
  }
  const content = document.createDocumentFragment();
  renderBlocks(body, content, options, depth + 1);
  const first = content.firstChild;
  if (!loose && first && first.nodeName === 'P') {
    while (first.firstChild) content.insertBefore(first.firstChild, first);
    content.removeChild(first);
  }
  item.append(content);
  return item;
}

// ------------------------------------------------------------------ inline

function renderInline(text, parent) {
  inline(text, parent, 0);
}

function inline(text, parent, depth) {
  // Remembers searches that found nothing, so text full of unmatched * or ` stays fast.
  // Positions only make sense within one string, so each call has its own.
  const memo = { closers: new Map(), ticks: new Map() };
  if (depth > MAX_DEPTH) {
    parent.append(text);
    return;
  }
  let buffer = '';
  const flush = () => {
    if (buffer) parent.append(buffer);
    buffer = '';
  };

  let i = 0;
  while (i < text.length) {
    const c = text[i];

    if (c === '\\') {
      const next = text[i + 1];
      if (next === '\n') {
        flush();
        parent.append(el('br'));
        i += 2;
        continue;
      }
      if (next !== undefined && ESCAPABLE.test(next)) {
        buffer += next;
        i += 2;
        continue;
      }
      buffer += c;
      i += 1;
      continue;
    }

    if (c === '\n') {
      if (/ {2,}$/.test(buffer)) {
        buffer = buffer.replace(/ +$/, '');
        flush();
        parent.append(el('br'));
      } else {
        buffer = `${buffer.replace(/ +$/, '')}\n`;
      }
      i += 1;
      continue;
    }

    if (c === '`') {
      const run = runLength(text, i, '`');
      const close = findTicks(text, i + run, run, memo);
      if (close >= 0) {
        flush();
        let code = text.slice(i + run, close).replace(/\n/g, ' ');
        if (code.length > 2 && code.startsWith(' ') && code.endsWith(' ') && code.trim()) code = code.slice(1, -1);
        parent.append(el('code', null, code));
        i = close + run;
        continue;
      }
      buffer += text.slice(i, i + run);
      i += run;
      continue;
    }

    if (c === '!' && text[i + 1] === '[') {
      const found = readLink(text, i + 1, memo);
      if (found) {
        flush();
        const label = `Image: ${found.label || found.url}`;
        const href = safeUrl(found.url);
        parent.append(href ? link(href, label) : label);
        i = found.end;
        continue;
      }
    }

    if (c === '[') {
      const found = readLink(text, i, memo);
      if (found) {
        flush();
        const href = safeUrl(found.url);
        if (href) {
          const anchor = link(href);
          if (found.title) anchor.title = found.title;
          inline(found.label, anchor, depth + 1);
          parent.append(anchor);
        } else {
          inline(found.label, parent, depth + 1); // unsafe address: keep the words only
        }
        i = found.end;
        continue;
      }
    }

    if (c === '<') {
      const rest = text.slice(i, i + 2048);
      const auto = /^<((?:https?:\/\/|mailto:)[^\s<>]+)>/i.exec(rest);
      const email = auto ? null : /^<([^\s<>@]+@[^\s<>@]+\.[^\s<>@]+)>/.exec(rest);
      if (auto || email) {
        flush();
        parent.append(auto ? link(auto[1], auto[1]) : link(`mailto:${email[1]}`, email[1]));
        i += (auto || email)[0].length;
        continue;
      }
    }

    if ((c === 'h' || c === 'H' || c === 'w' || c === 'W') && (i === 0 || /[\s(*_~"']/.test(text[i - 1]))) {
      const head = text.slice(i, i + 8).toLowerCase();
      if (head.startsWith('http://') || head.startsWith('https://') || head.startsWith('www.')) {
        const found = /^[^\s<]+/.exec(text.slice(i, i + 2048));
        const url = trimUrl(found[0]);
        if (/^(?:https?:\/\/[^/\s]+|www\.[^/\s]+\.[^/\s]+)/i.test(url)) {
          flush();
          parent.append(link(/^www\./i.test(url) ? `https://${url}` : url, url));
          i += url.length;
          continue;
        }
      }
    }

    if (c === '*' || c === '_' || c === '~') {
      const run = runLength(text, i, c);
      const valid = c === '~' ? run === 2 : run <= 3;
      const before = i > 0 ? text[i - 1] : ' ';
      const after = text[i + run] ?? ' ';
      const canOpen = valid && !SPACE.test(after) && !(c === '_' && WORD_CHAR.test(before));
      const close = canOpen ? findCloser(text, i + run, c, run, memo) : -1;
      if (close > i + run) {
        flush();
        const inner = text.slice(i + run, close);
        let outer;
        let target;
        if (c === '~') {
          outer = el('del');
          target = outer;
        } else if (run === 1) {
          outer = el('em');
          target = outer;
        } else if (run === 2) {
          outer = el('strong');
          target = outer;
        } else {
          outer = el('strong');
          target = el('em');
          outer.append(target);
        }
        inline(inner, target, depth + 1);
        parent.append(outer);
        i = close + run;
        continue;
      }
      buffer += text.slice(i, i + run);
      i += run;
      continue;
    }

    buffer += c;
    i += 1;
  }
  flush();
}

function runLength(text, start, char) {
  let end = start;
  while (text[end] === char) end += 1;
  return end - start;
}

/** Position of the next run of exactly `size` backticks at or after `from`, or -1. */
function findTicks(text, from, size, memo) {
  const failedFrom = memo.ticks.get(size);
  if (failedFrom !== undefined && from >= failedFrom) return -1;
  let k = text.indexOf('`', from);
  while (k >= 0) {
    const run = runLength(text, k, '`');
    if (run === size) return k;
    k = text.indexOf('`', k + run);
  }
  memo.ticks.set(size, Math.min(from, failedFrom ?? Infinity));
  return -1;
}

/** Position of the run that closes an emphasis opened with `size` × `char`, or -1. */
function findCloser(text, from, char, size, memo) {
  const key = char + size;
  const failedFrom = memo.closers.get(key);
  if (failedFrom !== undefined && from >= failedFrom) return -1;
  let k = from;
  while (k < text.length) {
    const c = text[k];
    if (c === '\\') {
      k += 2;
      continue;
    }
    if (c === '`') {
      const run = runLength(text, k, '`');
      const end = findTicks(text, k + run, run, memo);
      k = end >= 0 ? end + run : k + run;
      continue;
    }
    if (c === char) {
      const run = runLength(text, k, char);
      const afterRun = text[k + run] ?? '';
      if (run === size && !SPACE.test(text[k - 1]) && !(char === '_' && WORD_CHAR.test(afterRun))) return k;
      k += run;
      continue;
    }
    k += 1;
  }
  memo.closers.set(key, Math.min(from, failedFrom ?? Infinity));
  return -1;
}

/** Reads [label](url "title") starting at the '['. Returns null if it isn't a complete link. */
function readLink(text, start, memo) {
  let depth = 0;
  let k = start;
  for (; k < text.length; k += 1) {
    const c = text[k];
    if (c === '\\') {
      k += 1;
    } else if (c === '`') {
      const run = runLength(text, k, '`');
      const end = findTicks(text, k + run, run, memo);
      k = (end >= 0 ? end + run : k + run) - 1;
    } else if (c === '[') {
      depth += 1;
    } else if (c === ']') {
      depth -= 1;
      if (depth === 0) break;
    }
  }
  if (k >= text.length || text[k + 1] !== '(') return null;
  const label = text.slice(start + 1, k);

  let p = k + 2;
  while (text[p] === ' ') p += 1;
  let url;
  if (text[p] === '<') {
    const end = text.indexOf('>', p);
    if (end < 0) return null;
    url = text.slice(p + 1, end);
    p = end + 1;
  } else {
    const begin = p;
    let parens = 0;
    while (p < text.length && !SPACE.test(text[p])) {
      if (text[p] === '\\') {
        p += 2;
        continue;
      }
      if (text[p] === '(') parens += 1;
      if (text[p] === ')') {
        if (parens === 0) break;
        parens -= 1;
      }
      p += 1;
    }
    url = text.slice(begin, p);
  }
  while (text[p] === ' ') p += 1;
  let title = '';
  if (text[p] === '"' || text[p] === "'") {
    const end = text.indexOf(text[p], p + 1);
    if (end < 0) return null;
    title = text.slice(p + 1, end);
    p = end + 1;
    while (text[p] === ' ') p += 1;
  }
  if (text[p] !== ')') return null;
  return { label, url: url.replace(/\\(.)/g, '$1'), title, end: p + 1 };
}

function trimUrl(url) {
  let result = url.replace(/[.,;:!?'"*_~]+$/, '');
  const count = (s, ch) => s.split(ch).length - 1;
  while (result.endsWith(')') && count(result, '(') < count(result, ')')) {
    result = result.slice(0, -1).replace(/[.,;:!?'"*_~]+$/, '');
  }
  return result;
}

/** Returns the address if it's safe to link to, otherwise null. */
export function safeUrl(url) {
  const value = String(url ?? '').trim();
  if (/^(?:https?:|mailto:)/i.test(value)) return value;
  if (/^(?:#|\/(?!\/)|\.\.?\/)/.test(value)) return value;
  return null;
}

function link(href, text) {
  const anchor = el('a');
  anchor.setAttribute('href', href);
  anchor.setAttribute('target', '_blank');
  anchor.setAttribute('rel', 'noopener noreferrer');
  if (text !== undefined) anchor.textContent = text;
  return anchor;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = text;
  return node;
}
