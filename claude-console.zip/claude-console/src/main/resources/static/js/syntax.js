// Light syntax coloring for code blocks, written for this page so it needs no npm packages.
// It wraps comments, strings, numbers and common keywords in <span>s. Everything is inserted as
// text, so code in an answer can never run. Unknown languages are shown uncolored.

const DQ = String.raw`"(?:[^"\\\n]|\\.)*"?`;
const SQ = String.raw`'(?:[^'\\\n]|\\.)*'?`;
const BQ = String.raw`\`(?:[^\`\\]|\\.)*\`?`;
const NUMBER = String.raw`\b0[xX][\da-fA-F_]+\b|\b\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?[fFlLdDuU]?\b`;
const NEVER = '(?!)';

const CODE_KEYWORDS = new Set(`
  abstract and as assert async await boolean break byte case catch char class const continue def default
  defer del delete do done double elif else end enum esac except export extends false False fi final finally
  float fn for from func function global go if impl implements import in instanceof int interface is lambda
  let local long match mod module mut namespace new nil None nonlocal not null or package pass private
  protected pub public raise readonly record return self short static struct super switch synchronized then
  this throw throws trait true True try type typeof unset use using val var void volatile when where while
  with yield
`.trim().split(/\s+/));

const SQL_KEYWORDS = new Set(`
  add all alter and as asc begin between by case check column commit constraint create cross default delete
  desc distinct drop else end exists fetch for foreign from full grant group having in index inner insert
  into is join key left like limit merge not null offset on or order outer over partition primary
  references returning right rollback select set table then top truncate union unique update using values
  view when where with
`.trim().split(/\s+/));

function family(comment, strings, word, flags, extra = {}) {
  const source = `(${comment || NEVER})|(${strings || NEVER})|(${NUMBER})|(${word || NEVER})`;
  return { pattern: new RegExp(source, flags), ...extra };
}

const FAMILIES = {
  hash: family(String.raw`(?:^|(?<=\s))#.*`, `${DQ}|${SQ}`, String.raw`[A-Za-z_][\w]*`, 'gm', { keywords: CODE_KEYWORDS }),
  slash: family(String.raw`\/\/.*|\/\*[\s\S]*?(?:\*\/|$)`, `${DQ}|${SQ}|${BQ}`, String.raw`[A-Za-z_$][\w$]*`, 'g',
    { keywords: CODE_KEYWORDS }),
  dash: family(String.raw`--.*|\/\*[\s\S]*?(?:\*\/|$)`, String.raw`'(?:[^']|'')*'?`, String.raw`[A-Za-z_][\w]*`, 'g',
    { keywords: SQL_KEYWORDS, caseless: true }),
  css: family(String.raw`\/\*[\s\S]*?(?:\*\/|$)`, `${DQ}|${SQ}`, null, 'g'),
  markup: family(String.raw`<!--[\s\S]*?(?:-->|$)`, `${DQ}|${SQ}`, String.raw`<\/?[A-Za-z][\w:.-]*`, 'g',
    { wordClass: 'name' }),
  json: family(null, DQ, String.raw`\b(?:true|false|null)\b`, 'g', { wordClass: 'literal' }),
};

const LANGUAGES = new Map();
const register = (name, languages) => languages.forEach((language) => LANGUAGES.set(language, name));
register('hash', ['bash', 'sh', 'shell', 'zsh', 'ksh', 'console', 'terminal', 'python', 'py', 'ruby', 'rb', 'perl',
  'r', 'yaml', 'yml', 'toml', 'ini', 'conf', 'properties', 'dockerfile', 'docker', 'make', 'makefile',
  'powershell', 'ps1', 'pwsh', 'nginx', 'hcl', 'terraform', 'tf']);
register('slash', ['java', 'javascript', 'js', 'mjs', 'cjs', 'jsx', 'typescript', 'ts', 'tsx', 'c', 'h', 'cpp', 'c++',
  'cc', 'hpp', 'cs', 'csharp', 'c#', 'go', 'golang', 'rust', 'rs', 'kotlin', 'kt', 'kts', 'swift', 'scala',
  'groovy', 'gradle', 'php', 'dart', 'proto', 'protobuf', 'jsonc', 'json5', 'scss', 'less']);
register('dash', ['sql', 'mysql', 'postgresql', 'postgres', 'psql', 'plsql', 'tsql', 'sqlite', 'lua', 'haskell', 'hs']);
register('css', ['css']);
register('markup', ['html', 'htm', 'xml', 'xhtml', 'svg', 'xsd', 'xsl', 'jsp', 'vue', 'plist']);
register('json', ['json']);

/** Returns a DocumentFragment with the code, colored when the language is known. */
export function highlight(code, language) {
  const fragment = document.createDocumentFragment();
  const rules = FAMILIES[LANGUAGES.get(String(language || '').toLowerCase())];
  if (!rules || code.length > 100000) {
    fragment.append(code);
    return fragment;
  }
  let last = 0;
  for (const match of code.matchAll(rules.pattern)) {
    const [token, comment, string, number, word] = match;
    let kind = null;
    if (comment !== undefined) kind = 'comment';
    else if (string !== undefined) kind = 'string';
    else if (number !== undefined) kind = 'number';
    else if (word !== undefined) {
      if (rules.wordClass) kind = rules.wordClass;
      else if (rules.keywords.has(rules.caseless ? word.toLowerCase() : word)) kind = 'keyword';
    }
    if (!kind) continue;
    if (match.index > last) fragment.append(code.slice(last, match.index));
    const span = document.createElement('span');
    span.className = `hljs-${kind}`;
    span.textContent = token;
    fragment.append(span);
    last = match.index + token.length;
  }
  if (last < code.length) fragment.append(code.slice(last));
  return fragment;
}
