export function formatAgo(iso, now = Date.now()) {
  if (!iso) return '';
  const then = Date.parse(iso);
  if (Number.isNaN(then)) return '';
  const seconds = Math.max(0, Math.round((now - then) / 1000));
  if (seconds < 45) return 'just now';
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  return new Date(then).toLocaleString();
}

export function formatSeconds(ms) {
  if (ms == null) return '';
  const seconds = ms / 1000;
  return seconds < 10 ? `${seconds.toFixed(1)} s` : `${Math.round(seconds)} s`;
}

export function formatCost(usd) {
  if (usd == null) return '';
  if (usd === 0) return '$0';
  return usd < 0.01 ? `$${usd.toFixed(4)}` : `$${usd.toFixed(2)}`;
}

const RETRY_REASONS = {
  authentication_failed: 'the sign-in was rejected',
  oauth_org_not_allowed: "this sign-in isn't allowed for your organization",
  cloud_credential_error: 'the cloud credentials were rejected',
  account_on_hold: 'the account is on hold',
  billing_error: 'a billing problem',
  rate_limit: 'a rate limit',
  overloaded: 'a busy service',
  server_error: 'a server error',
  invalid_request: 'a rejected request',
  model_not_found: "a model that isn't available",
  max_output_tokens: 'an answer that hit its length limit',
};

export function describeRetry(error) {
  return RETRY_REASONS[error] || 'a temporary error';
}
