// Calls to the Spring Boot app. URLs are relative so the page works under any path.

export async function getStatus(signal) {
  const response = await fetch('api/status', {
    signal,
    cache: 'no-store',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`status request failed with HTTP ${response.status}`);
  return response.json();
}

export async function refreshStatus() {
  const response = await fetch('api/status/refresh', {
    method: 'POST',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`check failed with HTTP ${response.status}`);
  return response.json();
}

export async function cancelRun(runId) {
  await fetch(`api/chat/${encodeURIComponent(runId)}/cancel`, { method: 'POST' });
}

/**
 * Sends a question and calls onEvent(name, data) for every server-sent event until the
 * stream ends. Uses fetch rather than EventSource because the question is sent with POST.
 */
export async function streamChat({ prompt, sessionId }, onEvent, signal) {
  const response = await fetch('api/chat', {
    method: 'POST',
    signal,
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream, application/json',
    },
    body: JSON.stringify({ prompt, sessionId: sessionId || null }),
  });
  if (!response.ok || !response.body) {
    throw new Error(`the server answered with HTTP ${response.status}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let boundary = findBoundary(buffer);
    while (boundary) {
      dispatch(buffer.slice(0, boundary.index), onEvent);
      buffer = buffer.slice(boundary.index + boundary.length);
      boundary = findBoundary(buffer);
    }
  }
  buffer += decoder.decode();
  if (buffer.trim()) dispatch(buffer, onEvent);
}

function findBoundary(text) {
  const match = /\r?\n\r?\n/.exec(text);
  return match ? { index: match.index, length: match[0].length } : null;
}

/** Parses one server-sent-event block into { name, data }, or null if it has no data. */
export function parseEventBlock(block) {
  let name = 'message';
  const data = [];
  for (const line of block.split(/\r?\n/)) {
    if (!line || line.startsWith(':')) continue;
    const colon = line.indexOf(':');
    const field = colon === -1 ? line : line.slice(0, colon);
    let value = colon === -1 ? '' : line.slice(colon + 1);
    if (value.startsWith(' ')) value = value.slice(1);
    if (field === 'event') name = value;
    else if (field === 'data') data.push(value);
  }
  if (data.length === 0) return null;
  const text = data.join('\n');
  try {
    return { name, data: JSON.parse(text) };
  } catch {
    return { name, data: { text } };
  }
}

function dispatch(block, onEvent) {
  const event = parseEventBlock(block);
  if (event) onEvent(event.name, event.data);
}
