package com.example.claudeconsole.status;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ClaudeStatusServiceTest {

    @Test
    void authSummaryLeavesOutSecretsAndNestedValues() {
        String summary = ClaudeStatusService.summarizeAuth("{\"loggedIn\":true,\"authMethod\":\"claude.ai\","
                + "\"accessToken\":\"sk-secret\",\"apiKeySource\":\"none\",\"organization\":{\"id\":\"x\"}}");
        assertEquals("loggedIn: true, authMethod: claude.ai", summary);
        assertFalse(summary.contains("sk-secret"));
    }

    @Test
    void authSummaryFallsBackToFirstLine() {
        assertEquals("Logged in as someone", ClaudeStatusService.summarizeAuth("Logged in as someone\nmore"));
        assertTrue(ClaudeStatusService.summarizeAuth(null).isEmpty());
    }
}
