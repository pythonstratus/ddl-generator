package com.example.claudeconsole.web;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

class HostCheckTest {

    private static final List<String> ALLOWED = List.of("localhost", "127.0.0.1", "::1");

    @Test
    void readsHostHeaders() {
        assertEquals("localhost", HostCheck.hostFromHeader("localhost:8080"));
        assertEquals("localhost", HostCheck.hostFromHeader("LocalHost"));
        assertEquals("127.0.0.1", HostCheck.hostFromHeader("127.0.0.1"));
        assertEquals("::1", HostCheck.hostFromHeader("[::1]:8080"));
        assertEquals("::1", HostCheck.hostFromHeader("::1"));
        assertEquals("", HostCheck.hostFromHeader(null));
        assertEquals("", HostCheck.hostFromHeader("[::1"));
    }

    @Test
    void readsOriginHeaders() {
        assertEquals("localhost", HostCheck.hostFromOrigin("http://localhost:5173"));
        assertEquals("::1", HostCheck.hostFromOrigin("http://[::1]:8080"));
        assertEquals("attacker.example", HostCheck.hostFromOrigin("https://Attacker.example"));
        assertEquals("", HostCheck.hostFromOrigin("null"));
        assertEquals("", HostCheck.hostFromOrigin("http://bad host"));
    }

    @Test
    void allowsOnlyListedHosts() {
        assertTrue(HostCheck.isAllowed("localhost", ALLOWED));
        assertTrue(HostCheck.isAllowed("::1", List.of("[::1]")));
        assertFalse(HostCheck.isAllowed("localhost.attacker.example", ALLOWED));
        assertFalse(HostCheck.isAllowed("", ALLOWED));
        assertFalse(HostCheck.isAllowed("localhost", null));
        // DNS rebinding: an attacker's name that resolves to 127.0.0.1 still carries its own Host header.
        assertFalse(HostCheck.isAllowed(HostCheck.hostFromHeader("rebind.attacker.example:8080"), ALLOWED));
    }

    @Test
    void makesHeaderValuesSafeToLog() {
        assertEquals("evil?injected", HostCheck.forLog("evil\ninjected"));
        assertEquals("(none)", HostCheck.forLog(null));
        assertTrue(HostCheck.forLog("x".repeat(500)).length() <= 101);
    }
}
