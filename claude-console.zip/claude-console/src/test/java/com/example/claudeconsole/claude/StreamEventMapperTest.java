package com.example.claudeconsole.claude;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

class StreamEventMapperTest {

    private static final String SESSION = "0f8fad5b-d9cb-469f-a165-70867728950e";
    private static final String INIT = "{\"type\":\"system\",\"subtype\":\"init\",\"session_id\":\"" + SESSION
            + "\",\"model\":\"claude-test-1\",\"tools\":[],\"mcp_servers\":[]}";

    @Test
    void reportsModelAndConversationFromInit() {
        StreamEventMapper mapper = new StreamEventMapper();
        List<UiEvent> events = mapper.map(INIT);
        assertEquals(1, events.size());
        UiEvent init = events.get(0);
        assertEquals("init", init.name());
        assertEquals("claude-test-1", init.data().get("model"));
        assertEquals(SESSION, init.data().get("sessionId"));
        assertEquals(List.of(), init.data().get("riskyTools"));
        assertEquals("claude-test-1", mapper.model());
    }

    @Test
    void flagsToolsThatCanChangeThings() {
        UiEvent init = new StreamEventMapper().map("{\"type\":\"system\",\"subtype\":\"init\","
                + "\"tools\":[\"Read\",\"Bash\",\"mcp__tracker__search\",\"Grep\"]}").get(0);
        assertEquals(List.of("Bash", "mcp__tracker__search"), init.data().get("riskyTools"));
        assertEquals(List.of("Read", "Bash", "mcp__tracker__search", "Grep"), init.data().get("tools"));
    }

    @Test
    void streamsTextDeltas() {
        StreamEventMapper mapper = new StreamEventMapper();
        mapper.map(INIT);
        assertEquals(List.of(), mapper.map(streamEvent(blockStart(0))));
        assertEquals("Hel", onlyDelta(mapper.map(streamEvent(textDelta("Hel")))));
        assertEquals("lo \\u00e9", onlyDelta(mapper.map(streamEvent(textDelta("lo \\\\u00e9")))));
        // A second text block, after text was already sent, starts a new paragraph.
        assertEquals("\n\n", onlyDelta(mapper.map(streamEvent(blockStart(1)))));
        // Thinking and other deltas are skipped.
        assertEquals(List.of(), mapper.map(streamEvent("{\"type\":\"content_block_delta\",\"index\":0,"
                + "\"delta\":{\"type\":\"thinking_delta\",\"thinking\":\"hmm\"}}")));
        assertEquals(List.of(), mapper.map(streamEvent("{\"type\":\"message_delta\",\"delta\":"
                + "{\"stop_reason\":\"end_turn\"}}")));
    }

    @Test
    void decodesEscapedText() {
        StreamEventMapper mapper = new StreamEventMapper();
        String line = streamEvent("{\"type\":\"content_block_delta\",\"index\":0,\"delta\":{\"type\":"
                + "\"text_delta\",\"text\":\"caf\\u00e9\\n\\\"quoted\\\"\"}}");
        assertEquals("caf\u00e9\n\"quoted\"", onlyDelta(mapper.map(line)));
    }

    @Test
    void skipsSubagentOutput() {
        String line = "{\"type\":\"stream_event\",\"parent_tool_use_id\":\"toolu_1\",\"event\":"
                + textDelta("hidden") + "}";
        assertEquals(List.of(), new StreamEventMapper().map(line));
    }

    @Test
    void reportsRetries() {
        StreamEventMapper mapper = new StreamEventMapper();
        UiEvent retry = mapper.map("{\"type\":\"system\",\"subtype\":\"api_retry\",\"attempt\":2,"
                + "\"max_retries\":10,\"retry_delay_ms\":1500,\"error_status\":429,\"error\":\"rate_limit\"}").get(0);
        assertEquals("retry", retry.name());
        assertEquals(2L, ((Number) retry.data().get("attempt")).longValue());
        assertEquals(10L, ((Number) retry.data().get("maxRetries")).longValue());
        assertEquals(429L, ((Number) retry.data().get("httpStatus")).longValue());
        assertEquals("rate_limit", retry.data().get("error"));
        assertEquals("rate_limit", mapper.lastRetryError());
    }

    @Test
    void reportsAnswer() {
        StreamEventMapper mapper = new StreamEventMapper();
        mapper.map(INIT);
        UiEvent result = mapper.map("{\"type\":\"result\",\"subtype\":\"success\",\"is_error\":false,"
                + "\"result\":\"Hello\",\"session_id\":\"" + SESSION + "\",\"total_cost_usd\":0.0123,"
                + "\"duration_ms\":2100,\"num_turns\":1}").get(0);
        assertEquals("result", result.name());
        assertEquals("Hello", result.data().get("text"));
        assertEquals(Boolean.FALSE, result.data().get("isError"));
        assertEquals(SESSION, result.data().get("sessionId"));
        assertEquals("claude-test-1", result.data().get("model"));
        assertEquals(0.0123, ((Number) result.data().get("costUsd")).doubleValue(), 1e-9);
        assertEquals(2100L, ((Number) result.data().get("durationMs")).longValue());
        assertTrue(mapper.resultSeen());
        assertFalse(mapper.resultIsError());
        assertEquals("Hello", mapper.resultText());
    }

    @Test
    void reportsFailedRuns() {
        StreamEventMapper signIn = new StreamEventMapper();
        UiEvent auth = signIn.map("{\"type\":\"result\",\"subtype\":\"success\",\"is_error\":true,"
                + "\"result\":\"Invalid API key\"}").get(0);
        assertEquals(Boolean.TRUE, auth.data().get("isError"));
        assertEquals("Invalid API key", auth.data().get("text"));
        assertTrue(signIn.resultIsError());

        UiEvent turns = new StreamEventMapper().map("{\"type\":\"result\",\"subtype\":\"error_max_turns\"}").get(0);
        assertEquals(Boolean.TRUE, turns.data().get("isError"));
        assertTrue(((String) turns.data().get("text")).contains("turn limit"));

        UiEvent other = new StreamEventMapper().map("{\"type\":\"result\",\"subtype\":\"error_new_kind\"}").get(0);
        assertTrue(((String) other.data().get("text")).contains("error_new_kind"));
    }

    @Test
    void skipsEverythingElse() {
        StreamEventMapper mapper = new StreamEventMapper();
        assertEquals(List.of(), mapper.map(null));
        assertEquals(List.of(), mapper.map(""));
        assertEquals(List.of(), mapper.map("Warning: something happened"));
        assertEquals(List.of(), mapper.map("[1,2,3]"));
        assertEquals(List.of(), mapper.map("{\"type\":\"assistant\",\"message\":{\"content\":"
                + "[{\"type\":\"text\",\"text\":\"duplicate\"}]}}"));
        assertEquals(List.of(), mapper.map("{\"type\":\"user\",\"message\":{}}"));
        assertFalse(mapper.resultSeen());
    }

    private static String streamEvent(String event) {
        return "{\"type\":\"stream_event\",\"session_id\":\"" + SESSION + "\",\"parent_tool_use_id\":null,"
                + "\"event\":" + event + "}";
    }

    private static String blockStart(int index) {
        return "{\"type\":\"content_block_start\",\"index\":" + index
                + ",\"content_block\":{\"type\":\"text\",\"text\":\"\"}}";
    }

    private static String textDelta(String text) {
        return "{\"type\":\"content_block_delta\",\"index\":0,\"delta\":{\"type\":\"text_delta\",\"text\":\""
                + text + "\"}}";
    }

    private static String onlyDelta(List<UiEvent> events) {
        assertEquals(1, events.size());
        assertEquals("delta", events.get(0).name());
        return (String) events.get(0).data().get("text");
    }
}
