package com.example.claudeconsole.claude;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.example.claudeconsole.config.ClaudeProperties;

class ClaudeCommandBuilderTest {

    private static final String SESSION = "0f8fad5b-d9cb-469f-a165-70867728950e";

    @Test
    void buildsHeadlessStreamingCommand() {
        List<String> command = new ClaudeCommandBuilder(new ClaudeProperties()).chat(null);
        assertEquals(List.of("claude", "-p", "--output-format", "stream-json", "--verbose",
                "--include-partial-messages"), command.subList(0, 6));
        assertFalse(command.contains("--resume"));
        assertTrue(command.contains("--strict-mcp-config"));
        int flag = command.indexOf("--disallowedTools");
        assertTrue(flag > 0, "tools are turned off");
        assertEquals("*", command.get(flag + 1));
        assertEquals("mcp__*", command.get(command.size() - 1), "the tool list comes last");
    }

    @Test
    void continuesConversations() {
        List<String> command = new ClaudeCommandBuilder(new ClaudeProperties()).chat(SESSION);
        int resume = command.indexOf("--resume");
        assertTrue(resume > 0);
        assertEquals(SESSION, command.get(resume + 1));
        assertTrue(resume < command.indexOf("--disallowedTools"));
    }

    @Test
    void refusesConversationIdsThatAreNotUuids() {
        ClaudeCommandBuilder builder = new ClaudeCommandBuilder(new ClaudeProperties());
        assertThrows(IllegalArgumentException.class, () -> builder.chat("--dangerously-skip-permissions"));
        assertThrows(IllegalArgumentException.class, () -> builder.chat(SESSION + " --verbose"));
        assertThrows(IllegalArgumentException.class, () -> builder.chat(SESSION + "\n"));
        assertFalse(ClaudeCommandBuilder.isValidSessionId("abc"));
        assertFalse(ClaudeCommandBuilder.isValidSessionId(null));
        assertTrue(ClaudeCommandBuilder.isValidSessionId(SESSION.toUpperCase()));
    }

    @Test
    void usesConfiguredCommandModelAndTools() {
        ClaudeProperties props = new ClaudeProperties();
        props.setCommand(List.of("cmd.exe", "/c", "claude.cmd"));
        props.setModel(" sonnet ");
        props.setDisallowedTools(List.of());
        props.setExtraArgs(List.of("--max-turns", "3"));
        props.setPartialMessages(false);
        List<String> command = new ClaudeCommandBuilder(props).chat("");
        assertFalse(command.contains("--include-partial-messages"));
        assertTrue(command.contains("--verbose"), "stream-json output needs --verbose");
        assertEquals(List.of("cmd.exe", "/c", "claude.cmd", "-p"), command.subList(0, 4));
        assertEquals("sonnet", command.get(command.indexOf("--model") + 1));
        assertEquals(List.of("--max-turns", "3"), command.subList(command.size() - 2, command.size()));
        assertFalse(command.contains("--disallowedTools"));
    }

    @Test
    void refusesModelThatLooksLikeAFlag() {
        ClaudeProperties props = new ClaudeProperties();
        props.setModel("--dangerously-skip-permissions");
        assertThrows(IllegalStateException.class, () -> new ClaudeCommandBuilder(props).chat(null));
    }

    @Test
    void refusesEmptyCommand() {
        ClaudeProperties props = new ClaudeProperties();
        props.setCommand(List.of(" "));
        assertThrows(IllegalStateException.class, () -> new ClaudeCommandBuilder(props).version());
    }

    @Test
    void buildsStatusCommands() {
        ClaudeCommandBuilder builder = new ClaudeCommandBuilder(new ClaudeProperties());
        assertEquals(List.of("claude", "--version"), builder.version());
        assertEquals(List.of("claude", "auth", "status"), builder.authStatus());
        List<String> ping = builder.ping();
        assertEquals(List.of("claude", "-p", "--output-format", "json"), ping.subList(0, 4));
        assertEquals("mcp__*", ping.get(ping.size() - 1));
    }

    @Test
    void explainsUnsupportedFlags() {
        String text = ClaudeRunner.describeFailure(1, "error: unknown option '--include-partial-messages'");
        assertTrue(text.startsWith("Claude Code exited with code 1: error: unknown option"), text);
        assertTrue(text.contains("doesn't support one of the flags"), text);
        assertTrue(ClaudeRunner.describeFailure(0, "").contains("finished without an answer"));
    }
}
