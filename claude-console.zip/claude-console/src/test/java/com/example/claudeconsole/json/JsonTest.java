package com.example.claudeconsole.json;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class JsonTest {

    @Test
    void parsesNestedValues() {
        Map<String, Object> object = Json.asObject(Json.parse(
                " {\"a\": [1, -2, 3.5, 1e3, true, false, null], \"b\": {\"c\": \"d\"}, \"e\": {}} "));
        List<Object> a = Json.array(object, "a");
        assertEquals(List.of(1L, -2L, 3.5, 1000.0, true, false), a.subList(0, 6));
        assertNull(a.get(6));
        assertEquals("d", Json.string(Json.object(object, "b"), "c"));
        assertTrue(Json.object(object, "e").isEmpty());
    }

    @Test
    void decodesEscapes() {
        assertEquals("quote\" backslash\\ slash/ \n\t\u00e9\uD83D\uDE00",
                Json.parse("\"quote\\\" backslash\\\\ slash\\/ \\n\\t\\u00e9\\ud83d\\ude00\""));
    }

    @Test
    void keepsLargeIntegersExact() {
        assertEquals(9007199254740993L, ((Number) Json.parse("9007199254740993")).longValue());
        assertEquals(new BigInteger("123456789012345678901234567890"),
                Json.parse("123456789012345678901234567890"));
    }

    @Test
    void rejectsInvalidJson() {
        List<String> invalid = List.of("", "{", "{\"a\":}", "[1,]", "tru", "\"abc", "01", "1.", "-",
                "{\"a\":1}x", "\"a\u0001\"", "{a:1}", "\"\\x\"", "\"\\u12\"");
        for (String text : invalid) {
            assertThrows(IllegalArgumentException.class, () -> Json.parse(text), text);
        }
    }

    @Test
    void limitsNesting() {
        String deep = "[".repeat(10_000) + "]".repeat(10_000);
        assertThrows(IllegalArgumentException.class, () -> Json.parse(deep));
    }

    @Test
    void parseObjectOrNullIgnoresOtherInput() {
        assertNull(Json.parseObjectOrNull("not json"));
        assertNull(Json.parseObjectOrNull("[1,2]"));
        assertNull(Json.parseObjectOrNull("  "));
        assertEquals("x", Json.string(Json.parseObjectOrNull("{\"t\":\"x\"}"), "t"));
    }

    @Test
    void helpersTolerateWrongTypes() {
        Map<String, Object> object = Json.asObject(Json.parse("{\"n\":\"text\",\"s\":5,\"b\":\"true\"}"));
        assertNull(Json.number(object, "n"));
        assertEquals("", Json.string(object, "s"));
        assertFalse(Json.bool(object, "b"));
        assertTrue(Json.array(object, "missing").isEmpty());
    }

    @Test
    void writesAsciiOnly() {
        Map<String, Object> value = new LinkedHashMap<>();
        value.put("text", "\u00e9 \"q\" \n\u2028\uD83D\uDE00");
        value.put("n", 3L);
        value.put("d", 0.25);
        value.put("whole", 2.0);
        value.put("list", Arrays.asList(true, null, "x"));
        value.put("nan", Double.NaN);
        String json = Json.write(value);
        assertTrue(json.chars().allMatch(c -> c >= 0x20 && c < 0x7f), json);
        assertEquals("{\"text\":\"\\u00e9 \\\"q\\\" \\n\\u2028\\ud83d\\ude00\",\"n\":3,\"d\":0.25,"
                + "\"whole\":2,\"list\":[true,null,\"x\"],\"nan\":null}", json);
    }

    @Test
    void roundTrips() {
        Map<String, Object> value = new LinkedHashMap<>();
        value.put("text", "line one\nline two \u00fc \uD83D\uDE00 </script>");
        value.put("nested", Map.of("k", List.of(1L, 2L)));
        value.put("empty", List.of());
        assertEquals(value, Json.parse(Json.write(value)));
    }
}
