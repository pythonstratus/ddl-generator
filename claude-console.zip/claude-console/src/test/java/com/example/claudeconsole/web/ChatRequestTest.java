package com.example.claudeconsole.web;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ChatRequestTest {

    @Test
    void readsQuestionAndConversation() {
        ChatRequest request = ChatRequest.fromJson(
                "{\"prompt\":\"  What is TLS?  \",\"sessionId\":\"0f8fad5b-d9cb-469f-a165-70867728950e\"}", 100);
        assertEquals("What is TLS?", request.prompt());
        assertEquals("0f8fad5b-d9cb-469f-a165-70867728950e", request.sessionId());
    }

    @Test
    void treatsNullConversationAsNew() {
        assertEquals("", ChatRequest.fromJson("{\"prompt\":\"hi\",\"sessionId\":null}", 100).sessionId());
    }

    @Test
    void explainsBadRequests() {
        assertEquals("The request wasn't valid JSON.",
                assertThrows(IllegalArgumentException.class, () -> ChatRequest.fromJson("{", 100)).getMessage());
        assertEquals("Type a question first.",
                assertThrows(IllegalArgumentException.class,
                        () -> ChatRequest.fromJson("{\"prompt\":\"   \"}", 100)).getMessage());
        String tooLong = assertThrows(IllegalArgumentException.class,
                () -> ChatRequest.fromJson("{\"prompt\":\"" + "x".repeat(2_000) + "\"}", 1_000)).getMessage();
        assertTrue(tooLong.contains("2,000") && tooLong.contains("1,000"), tooLong);
        assertThrows(IllegalArgumentException.class,
                () -> ChatRequest.fromJson("{\"prompt\":\"hi\",\"sessionId\":\"--resume\"}", 100));
    }
}
