package com.example.claudeconsole.web;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class SecurityHeadersTest {

    @Test
    void policyAllowsOnlyThisAppsOwnFiles() {
        String policy = SecurityHeaders.ALL.get("Content-Security-Policy");
        assertTrue(policy.contains("script-src 'self'"));
        assertTrue(policy.contains("frame-ancestors 'none'"));
        assertFalse(policy.contains("unsafe-inline"), "no inline scripts or styles");
        assertFalse(policy.contains("unsafe-eval"));
        assertFalse(policy.contains("http"), "no other sites");
    }
}
