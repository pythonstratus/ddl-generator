# Claude console

A small web page for asking Claude questions through the **Claude Code CLI** on your own computer.

It's meant for environments where the CLI is the approved way to reach Claude. For each question, the Java app runs `claude -p` (headless mode) and streams the answer to a React page. Lights at the top of the page show whether everything is connected.

![The console showing a formatted answer below the row of status lights](docs/screenshot.png)

```text
 Browser (React page)            Spring Boot app (this JAR)           Claude Code CLI
┌─────────────────────┐ POST    ┌──────────────────────────┐ stdin  ┌─────────────────────────┐
│ question box        │ ──────▶ │ ChatController           │ ─────▶ │ claude -p               │
│ formatted answer    │ ◀────── │ ClaudeRunner             │ ◀───── │   --output-format       │
│ status lights       │  SSE    │ ClaudeStatusService      │  JSON  │     stream-json         │
└─────────────────────┘         └──────────────────────────┘  lines └─────────────────────────┘
```

## What you need

- **Java 17 or later.** You need a JDK to build. A JRE is enough to run the JAR.
- **Apache Maven 3.9 or later.**
- **Claude Code**, installed and signed in for the user account that will run the app. Check in a terminal:

  ```bash
  claude --version
  claude -p "Reply with the single word OK."
  ```

- **Network access during the build** to Maven Central, nodejs.org and the npm registry, or to internal mirrors of them. See [Building on a restricted network](#building-on-a-restricted-network).

You don't need Node.js installed: the build downloads its own copy into `frontend/node`.

## Build and run

```bash
mvn clean package
java -jar target/claude-console-1.0.0.jar
```

Open **<http://localhost:8080>**. To stop the app, press Ctrl+C in its terminal.

The first build takes a few minutes, because it also downloads Node.js and the page's npm packages into `frontend/`. Later builds reuse them.

The JAR is self-contained. You can copy it to any machine that has Java 17 or later and a signed-in Claude Code, and run it there.

## Using the page

- **Ask:** type a question and press **Enter**. Shift+Enter adds a new line.
  - The answer appears as it's written, with tables, lists and code blocks formatted.
  - Each code block and each answer has a copy button.
- **Follow up:** follow-up questions continue the same Claude Code session, so Claude remembers the conversation. **New conversation** starts fresh.
- **Stop:** ends the current answer. Claude Code can't cleanly continue a session that was stopped part-way, so your next question starts a new conversation.
- **Tools are off:** Claude can answer and write code for you to copy, but it can't run commands, change files or browse the web. If a question ever runs with one of those tools turned on, the page shows a warning above the answer.

### Status lights

| Light | What it tells you | How it's checked |
| --- | --- | --- |
| **App server** | The page can reach this Java app. | The page asks every 5 seconds. |
| **Claude Code** | The CLI starts, and which version it is. | `claude --version`, every 60 seconds. |
| **Sign-in** | Claude Code can reach Claude with your credentials. | Depends on `claude.status.check`. See [Sign-in checks](#sign-in-checks). |
| **Last question** | How your most recent question ended, and when. | Updated after every question. |

Each state has its own shape as well as its own color, so the lights don't rely on color vision:

- **Green circle:** working.
- **Amber triangle:** worth a look.
- **Red diamond:** a problem.
- **Grey ring:** not known yet.

**Details** explains each light in full. **Check again** runs the checks right away.

## Configuration

Settings are in `src/main/resources/application.yml`, with comments. You can change them without rebuilding, in any of these ways:

- **On the command line:**
  `java -jar target/claude-console-1.0.0.jar --server.port=9090 --claude.model=opus`
- **In a file:** put an `application.yml` (or `config/application.yml`) in the folder you start the app from. Spring Boot reads it automatically, and its values override the built-in ones.
- **With environment variables:** for example `SERVER_PORT=9090` or `CLAUDE_TIMEOUTSECONDS=900`. Dots become underscores and dashes are dropped.

| Setting | Default | What it does |
| --- | --- | --- |
| `server.address` | `127.0.0.1` | Only this computer can open the page. Keep it; see [Security](#security). |
| `server.port` | `8080` | Port for the page. |
| `console.allowed-hosts` | `localhost`, `127.0.0.1`, `::1` | Host names the browser may use to reach the app. |
| `claude.command` | `claude` | How to start Claude Code, one word per list item. |
| `claude.working-dir` | `~/.claude-console/workspace` | Folder Claude Code runs in. Keep it empty. |
| `claude.model` | *(blank)* | Model alias or full model name. Blank uses Claude Code's default. |
| `claude.disallowed-tools` | `*` plus named tools | Tools removed from every question. |
| `claude.partial-messages` | `true` | Shows answers as they're written. Set `false` for Claude Code versions without `--include-partial-messages`. |
| `claude.extra-args` | `--strict-mcp-config` | Extra CLI flags for every question. |
| `claude.timeout-seconds` | `600` | Stops an answer after this many seconds (minimum 10). |
| `claude.max-concurrent-runs` | `2` | How many questions can run at the same time. |
| `claude.max-prompt-chars` | `100000` | Longest question accepted, in characters. |
| `claude.status.check` | `auth-status` | How the Sign-in light is checked: `auth-status`, `prompt` or `none`. |
| `claude.status.interval-ms` | `60000` | Time between automatic checks, in milliseconds. |
| `claude.status.prompt-interval-minutes` | `30` | In `prompt` mode, minutes between automatic test prompts. |
| `claude.status.timeout-seconds` | `60` | Gives up on a check after this many seconds. |

### Examples

This `application.yml`, placed next to the JAR, uses the full path to Claude Code, a specific model and a longer timeout:

```yaml
claude:
  command:
    - /opt/claude/bin/claude
  model: opus
  timeout-seconds: 900
```

This one adds an instruction to every question with `--append-system-prompt`:

```yaml
claude:
  extra-args:
    - "--strict-mcp-config"
    - "--append-system-prompt"
    - "Answer in plain language for a non-technical reader."
```

Setting `extra-args` replaces the whole default list. Keep `--strict-mcp-config` in it; without that flag, any MCP servers in your Claude Code settings start with every question.

### Letting Claude read files in one folder (optional)

By default Claude can't open any files. You can let it read, but not change, the files in one folder:

1. Point the working folder at that folder.
2. Remove `"*"` from the deny list. This turns the read-only tools (such as Read, Grep and Glob) back on, while the tools that change things stay off.

```yaml
claude:
  working-dir: /data/reports-for-claude
  disallowed-tools: ["Bash", "PowerShell", "Edit", "MultiEdit", "Write", "NotebookEdit", "WebFetch", "WebSearch", "mcp__*"]
```

Use a folder that holds only the documents. Claude Code loads settings, hooks and MCP servers from a `.claude/` folder or `.mcp.json` file in its working folder, so the folder must not contain those.

In this setup, two warnings are expected or worth watching:

- The app warns at startup that the working folder isn't empty. That's expected here.
- The page warns if a question runs with a tool that can change things. That means something is wrong with the deny list.

## Sign-in checks

`claude.status.check` decides how the **Sign-in** light is checked:

- **`auth-status`** (default) runs `claude auth status`, which costs nothing.
  - It understands Claude account sign-ins.
  - The light shows *Signed in* or *Not signed in*, with details such as the sign-in method.
  - Tokens and other secrets are never shown.
- **`prompt`** sends the test prompt "Reply with the single word OK."
  - It works with any setup, including Amazon Bedrock, Google Vertex AI, Microsoft Foundry and LLM gateways.
  - Each check uses a few tokens, so automatic checks run at most every 30 minutes. **Check again** always sends one.
- **`none`** turns the check off. The light turns green once a question is answered.

If your organization connects Claude Code through a cloud provider or a gateway, use `prompt` or `none`. In that setup, `claude auth status` may report no sign-in even though questions work. If that happens with the default setting, the light shows an amber *Can't confirm* rather than red.

Claude Code gets the same environment variables as the app. Set anything your organization's setup needs in the shell before running `java -jar`, for example:

- `CLAUDE_CODE_USE_BEDROCK`
- AWS or Google credentials
- `HTTPS_PROXY`

## Windows

If `claude --version` works in a Command Prompt, the default setting finds `claude.exe`.

If Claude Code was installed with npm, the command is a `claude.cmd` script, which Java can't start directly. Start it through `cmd.exe` instead:

```yaml
claude:
  command: ["cmd.exe", "/c", "claude.cmd"]
```

Or on the command line:

```bat
java -jar target\claude-console-1.0.0.jar --claude.command=cmd.exe,/c,claude.cmd
```

This is safe here. `cmd.exe` never sees anything typed in the page:

- Questions reach Claude Code through standard input.
- The only other value that comes from the browser, the conversation ID, must be a UUID.

If `claude` isn't on the `PATH` of the account that runs Java, find its full path with `where claude` and use that.

## Building on a restricted network

The build downloads from three places. Each can point at an internal mirror such as Artifactory or Nexus.

1. **Maven dependencies**, from Maven Central. Add a mirror to `~/.m2/settings.xml`:

   ```xml
   <settings>
     <mirrors>
       <mirror>
         <id>internal</id>
         <mirrorOf>*</mirrorOf>
         <url>https://artifactory.example.gov/artifactory/maven-remote/</url>
       </mirror>
     </mirrors>
   </settings>
   ```

2. **Node.js**, from nodejs.org. Pass a mirror that has the same folder layout as `https://nodejs.org/dist/`:

   ```bash
   mvn clean package -Dnode.download.root=https://artifactory.example.gov/artifactory/nodejs-dist/
   ```

   If the mirror has a different Node.js version (18 or later), add `-Dnode.version=v22.x.y`.

3. **npm packages**, from registry.npmjs.org. Copy `frontend/.npmrc.example` to `frontend/.npmrc` and set your registry there.

If you reach the internet through a proxy, define it in `~/.m2/settings.xml`. The Node.js download and npm use Maven's proxy settings too.

### Building the page with your own Node.js

If Maven can't download Node.js at all, build the page yourself with Node.js 18 or later, then tell Maven to skip those steps:

```bash
cd frontend
npm install
npm run build
cd ..
mvn clean package -Dskip.installnodenpm -Dskip.npm
```

`frontend/dist` is outside `target/`, so `mvn clean` doesn't delete it.

### Using Spring Boot 3.5

This project uses Spring Boot 4.1. If your mirror only has 3.5.x (open-source support ended on June 30, 2026), make three changes in `pom.xml`:

1. Set the parent version to `3.5.16`.
2. Rename `spring-boot-starter-webmvc` to `spring-boot-starter-web`.
3. Rename `spring-boot-starter-webmvc-test` to `spring-boot-starter-test`.

The Java code builds unchanged on both.

### Repeatable builds

After the first successful build, do two things:

1. Commit `frontend/package-lock.json`.
2. In `pom.xml`, change `install --no-audit --no-fund` to `ci --no-audit --no-fund`.

Every build then uses exactly the same npm package versions.

## Working on the code

For development, run the Java app and the page's development server in two terminals. This needs Node.js 18 or later on your `PATH`.

```bash
# Terminal 1: the Java app, without rebuilding the page
mvn spring-boot:run -Dskip.installnodenpm -Dskip.npm

# Terminal 2: the page, which reloads as you edit
cd frontend
npm install
npm run dev
```

Open **<http://localhost:5173>**. The development server forwards `/api` calls to the Java app on port 8080.

`mvn test` runs the unit tests, which cover:

- JSON parsing
- the stream-json mapping
- building the Claude Code command
- request checks and host checks

The tests don't start Claude Code.

To use your own package name, rename `com.example.claudeconsole` and change `groupId` in `pom.xml`.

## Security

Anyone who can open this page can ask Claude questions with your Claude Code sign-in. The app is built to stay private to you:

- **Local only.** It listens on `127.0.0.1`, so other computers can't connect.
  - To use it from another machine, keep that setting and use an SSH tunnel instead: run `ssh -L 8080:localhost:8080 you@server`, then open <http://localhost:8080> on your own computer.
- **Blocks attacks from web pages.** The app refuses requests addressed to a host name that isn't in `console.allowed-hosts`, and requests sent by another website's page. This stops DNS-rebinding and cross-site requests from pages you happen to visit.
- **Questions never touch the command line.**
  - Questions go to Claude Code through standard input, so they can't be read as CLI flags and don't appear in process lists.
  - The one browser value passed as an argument, the conversation ID, must be a UUID.
  - No shell is involved.
- **Tools are off.** Claude can't run commands, edit files, browse or use MCP servers. The page warns if that's ever not true for a question.
- **Empty working folder.** In `-p` mode, Claude Code loads settings, hooks and MCP servers from its working folder without asking. The app therefore uses a dedicated empty folder, and warns at startup if the folder isn't empty.
- **Answers can't run code in the page.** Answers are shown as Markdown, and any HTML in an answer is displayed as plain text.
- **Run it as yourself.** The app has no login of its own. Don't run it as root, Administrator or a shared service account.

**What gets recorded:**

- **The app log** contains the Claude Code commands the app runs and anything Claude Code prints to its error output. It doesn't contain your questions or answers.
- **Claude Code's own session history** is kept under `~/.claude/projects/`, because follow-up questions need it. Claude Code's `cleanupPeriodDays` setting controls how long it's kept.

Before relying on the app, check that a local web front end for Claude Code fits your organization's rules.

## Troubleshooting

| What you see | What to do |
| --- | --- |
| Claude Code light shows **Not found**. | `claude` isn't on the `PATH` of the account running Java. Set `claude.command` to the full path (find it with `which claude` or `where claude`). |
| Sign-in light shows **Not signed in**, but `claude` works in your terminal. | The app may be running as a different user or with different environment variables. If you use Bedrock, Vertex AI, Foundry or a gateway, set `claude.status.check=prompt`. |
| *exited with code 1: error: unknown option …* | Your Claude Code is older than this app expects. Update it with `claude update`. Or turn off the flag: for `--include-partial-messages`, set `claude.partial-messages=false`; for anything else, edit `claude.extra-args`. |
| Answers appear all at once instead of as they're written. | `claude.partial-messages` is off, or a proxy between the browser and the app is buffering the response. |
| **403** with *This app only answers requests addressed to this computer*. | You opened the page with a host name or IP address that isn't in `console.allowed-hosts`. Use <http://localhost:8080>, or add the name if you understand the risk. |
| Blank page, or 404 at <http://localhost:8080>. | The page wasn't included in the build; the startup log says so. Run `mvn clean package` without the skip flags, or build `frontend/` first. |
| Startup fails with *Port 8080 was already in use*. | Start the app with `--server.port=9090`. |
| *No answer after 600 seconds* | Raise `claude.timeout-seconds`. |
| *Claude Code is already answering 2 question(s)* | Wait for a question to finish, or raise `claude.max-concurrent-runs`. |
| *Retrying because of a rate limit* | Claude Code retries on its own. The answer continues once the service accepts the request. |
| Startup warning that the working folder isn't empty. | Empty the folder, or point `claude.working-dir` at an empty one. |
| The build fails while downloading Node.js or npm packages. | See [Building on a restricted network](#building-on-a-restricted-network). |

## How it works

For each question, the app runs this command directly, with no shell, and writes the question to its standard input:

```text
claude -p --output-format stream-json --verbose --include-partial-messages
       [--model <model>] [--resume <conversation-id>]
       --strict-mcp-config
       --disallowedTools "*" Bash PowerShell Edit MultiEdit Write NotebookEdit WebFetch WebSearch "mcp__*"
```

The app reads Claude Code's output line by line, turns it into a few simple events, and sends those to the page as server-sent events.

### HTTP API

| Method and path | What it does |
| --- | --- |
| `GET /api/status` | Returns the current state of the lights, as JSON. |
| `POST /api/status/refresh` | Runs the checks now, then returns the status. |
| `POST /api/chat` | Asks a question. Send `{"prompt": "...", "sessionId": null}`. The reply is a `text/event-stream`. |
| `POST /api/chat/{runId}/cancel` | Stops a running question. |

`POST /api/chat` sends these events, in this order:

| Event | Data |
| --- | --- |
| `start` | `runId`, used for cancelling. |
| `init` | `model`, `sessionId`, `tools`, `riskyTools`. |
| `delta` | `text`: the next piece of the answer. Repeats. |
| `retry` | `attempt`, `maxRetries`, `delayMs`, `httpStatus`, `error`. |
| `result` | `text`, `isError`, `subtype`, `sessionId`, `model`, `costUsd`, `durationMs`, `numTurns`. |
| `error` | `code`, `message`: the question couldn't be answered. |
| `done` | `runId`, `exitCode`, `stopped`, `timedOut`, `resetConversation`, `resetReason`. Always last. |

To try it from a terminal:

```bash
curl -N -H "Content-Type: application/json" \
     -d '{"prompt": "What is the capital of France?"}' \
     http://localhost:8080/api/chat
```

### Project layout

```text
claude-console/
├── pom.xml                    Maven build: Spring Boot app and React page in one JAR
├── src/main/java/com/example/claudeconsole/
│   ├── ClaudeConsoleApplication.java
│   ├── config/                settings classes and startup checks
│   ├── claude/                runs the CLI: command builder, output mapper, runner
│   ├── status/                checks behind the status lights
│   ├── json/                  small JSON reader and writer
│   └── web/                   REST and SSE controllers, local-only filter
├── src/main/resources/application.yml
├── src/test/java/...          unit tests
├── docs/screenshot.png
└── frontend/                  React page, built with Vite
    ├── package.json
    ├── vite.config.js
    ├── index.html
    └── src/
        ├── App.jsx            conversation state and streaming
        ├── api.js             calls to the Java app, SSE parsing
        ├── components/        StatusPanel, Message, Composer
        └── styles.css
```

The JSON code is written in-house rather than using Jackson. That way the same Java code builds on Spring Boot 4 (which uses Jackson 3) and Spring Boot 3.5 (which uses Jackson 2) without changes.
